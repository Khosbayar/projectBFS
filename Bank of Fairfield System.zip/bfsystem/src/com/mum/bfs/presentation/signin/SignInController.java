package com.mum.bfs.presentation.signin;

import java.io.IOException;

import com.mum.bfs.business.models.User;
import com.mum.bfs.business.services.*;
import com.mum.bfs.presentation.banker.layout.BankerMenu;
import com.mum.bfs.tools.Result;
import com.mum.bfs.tools.Tools;
import com.sun.media.jfxmediaimpl.platform.Platform;
import com.sun.prism.paint.Stop;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class SignInController {

	@FXML
	TextField txtUserName;
	@FXML
	PasswordField txtPassword;

	@FXML
	public void initialize() {
//		txtUserName.setText("admin");
//		txtPassword.setText("pass");
	}

	@FXML
	protected void handleSubmitButtonAction(ActionEvent event) {
		Stage stage = new Stage();
		try {
			if (txtUserName.getText().trim().isEmpty() || txtPassword.getText().isEmpty()) {
				Tools.showAlert("Please insert your user name and password.");
				return;
			}

			SecurityService ss = new SecurityService();
			Result<User> res = ss.Authenticate(txtUserName.getText().trim(), txtPassword.getText());
			if (res.RetType != 0) {
				Tools.showAlert(res.RetDesc);
				return;
			}

			FormSignIn.setConnUser(res.RetData);

			if (res.RetData.getRoleID() == 2) {
				Parent root = FXMLLoader
						.load(getClass().getResource("/com/mum/bfs/presentation/client/layout/layout.fxml"));
				stage.setTitle("BFS - Client");
				stage.setScene(new Scene(root));
				stage.setResizable(false);
				Tools.setStageIcon(stage);
				stage.show();
			} else if (res.RetData.getRoleID() == 1) {
				// com.mum.bfs.presentation.banker.layout.BankerMenu bankerMenu = new
				// com.mum.bfs.presentation.banker.layout.BankerMenu(
				// FormSignIn.getPrimaryStage());
				// bankerMenu.show();
				Parent root = FXMLLoader
						.load(getClass().getResource("/com/mum/bfs/presentation/banker/layout/layout.fxml"));
				stage.setTitle("BFS - Banker");
				stage.setScene(new Scene(root));
				stage.setResizable(true);
				Tools.setStageIcon(stage);
				stage.show();

			}
			afterShowStage();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@FXML
	protected void handleSubmitButtonActionTmp(ActionEvent event) {
//		txtUserName.setText("admin");
//		txtPassword.setText("pass");
		handleSubmitButtonAction(event);
	}

	private void afterShowStage() {
		FormSignIn.getPrimaryStage().hide();
	}
}
