package com.mum.bfs.presentation.signin;

import com.mum.bfs.business.models.User;
import com.mum.bfs.tools.Tools;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.scene.Scene;

public class FormSignIn extends Application {
	static Stage primaryStage;

	@Override
	public void start(Stage stage) {
		try {
			Parent root = FXMLLoader.load(getClass().getResource("FormSignIn.fxml"));
			primaryStage = stage;
			stage.setTitle("Sign In");
			stage.setScene(new Scene(root));
			stage.setResizable(false);
			Tools.setStageIcon(stage);
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		launch(args);
	}

	public static Stage getPrimaryStage() {
		return primaryStage;
	}

	private static User connUser;

	public static User getConnUser() {
		return connUser;
	}

	public static void setConnUser(User user) {
		if (connUser == null) {
			connUser = user;
		}
	}

}
