package com.mum.bfs.presentation.banker.clientdetail;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.mum.bfs.business.interfaces.Account;
import com.mum.bfs.business.interfaces.Person;
import com.mum.bfs.business.models.AccountFactory;
import com.mum.bfs.business.models.Client;
import com.mum.bfs.business.models.PersonFactory;
import com.mum.bfs.business.models.User;
import com.mum.bfs.business.services.AccountService;
import com.mum.bfs.business.services.ClientService;
import com.mum.bfs.business.services.PersonService;
import com.mum.bfs.business.services.UserService;
import com.mum.bfs.tools.AcntListItem;
import com.mum.bfs.tools.FilterListForAccount;
import com.mum.bfs.tools.Tools;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

public class ClientDetail {
	@FXML
	TextField txtFirstName;
	@FXML
	TextField txtMiddleName;

	@FXML
	TextField txtLastName;

	@FXML
	TextField txtSSN;
	@FXML
	ComboBox<String> cboGender;
	@FXML
	DatePicker dateBirth;
	@FXML
	TextField txtEMail;
	@FXML
	TextField txtPhone;
	@FXML
	TextField txtPhone2;
	@FXML
	TextField txtStreet;
	@FXML
	TextField txtCity;
	@FXML
	TextField txtState;

	@FXML
	Tab tabMain;
	@FXML
	Tab tabAccounts;
	@FXML
	Tab tabUser;

	// ACCOUNT SECTION
	@FXML
	TextField txtAcntNo;
	@FXML
	TextField txtAcntName;
	@FXML
	ComboBox<String> cboAcntType;
	@FXML
	ComboBox<String> cboAcntMaturity;

	@FXML
	TextField txtUserName;
	@FXML
	TextField txtUserPassword;
	@FXML
	ComboBox<String> cboUserStatus;
	@FXML
	Label lblUserLastLoggedOn;

	@FXML
	TableColumn<AcntListItem, String> colAcntNo;
	@FXML
	TableColumn<AcntListItem, String> colAcntName;
	@FXML
	TableColumn<AcntListItem, String> colAcntType;
	@FXML
	TableColumn<AcntListItem, String> colAcntMaturity;
	@FXML
	TableColumn<AcntListItem, String> colAcntBal;
	@FXML
	TableView<AcntListItem> accountTable;

	@FXML
	void initialize() {
		cboGender.getItems().addAll("Male", "Female");
		cboGender.getSelectionModel().selectFirst();
		cboAcntType.getItems().addAll("1 - Checking", "2 - Savings");
		cboAcntType.getSelectionModel().selectFirst();
		cboAcntMaturity.getItems().addAll("1 - month", "2 - months", "3 - months", "6 - months");
		cboAcntMaturity.getSelectionModel().selectFirst();

		cboUserStatus.getItems().addAll("1 - Active", "0 - Inactive");
		cboUserStatus.getSelectionModel().selectFirst();

		tabAccounts.setDisable(true);
		tabUser.setDisable(true);

		colAcntNo.setMinWidth(100);
		colAcntNo.setCellValueFactory(new PropertyValueFactory<AcntListItem, String>("AcntNo"));
		colAcntName.setMinWidth(100);
		colAcntName.setCellValueFactory(new PropertyValueFactory<AcntListItem, String>("AcntName"));
		colAcntType.setMinWidth(100);
		colAcntType.setCellValueFactory(new PropertyValueFactory<AcntListItem, String>("AcntType"));
		colAcntMaturity.setMinWidth(100);
		colAcntMaturity.setCellValueFactory(new PropertyValueFactory<AcntListItem, String>("AcntMaturity"));
		colAcntBal.setMinWidth(100);
		colAcntBal.setCellValueFactory(new PropertyValueFactory<AcntListItem, String>("AcntBal"));

//		LoadClient(65754);
	}

	@FXML
	void onMainSave(ActionEvent event) {

		PersonService personService = new PersonService();
		ClientService clientService = new ClientService();

		int ID = 20000; // person id not matter
		String LastName = txtLastName.getText();
		String MiddleName = txtMiddleName.getText();
		String FirstName = txtFirstName.getText();
		LocalDate BirthDate = dateBirth.getValue();
		String Sex = cboGender.getValue();
		String SSN = txtSSN.getText();
		String EmailAddress = txtEMail.getText();
		String No = "";
		String Street = txtStreet.getText();
		String City = txtCity.getText();
		String State = txtState.getText();
		String Zip = "";
		String motherMaidenName = "";
		String signature = "";
		String photo = "";
		String phone = txtPhone.getText();
		String phone2 = txtPhone2.getText();

		StringBuilder sb = new StringBuilder();
		if (LastName.isEmpty())
			sb.append("Last name cannot be empty" + System.lineSeparator());
		if (MiddleName.isEmpty())
			sb.append("Middle Name cannot be empty" + System.lineSeparator());
		if (FirstName.isEmpty())
			sb.append("First Name cannot be empty" + System.lineSeparator());
		if (BirthDate == null)
			sb.append("Birthday cannot be empty" + System.lineSeparator());

		if (sb.length() > 0) {
			Tools.showAlert(sb.toString());
			return;
		}

		int clientID = 80000; // does not matter for now
		Client client = PersonFactory.createClient(ID, LastName, MiddleName, FirstName, clientID);
		client.setLastName(LastName);
		client.setMiddleName(MiddleName);
		client.setFirstName(FirstName);
		client.setBirthDate(BirthDate);
		client.setSex(Sex);
		client.setSSN(SSN);
		client.setNo(No);
		client.setEmailAddress(EmailAddress);
		client.setStreet(Street);
		client.setCity(City);
		client.setState(State);
		client.setZip(Zip);
		client.setPhoto(photo);
		client.setSignature(signature);
		client.setMotherMaidenName(motherMaidenName);
		client.setContactPhone(phone);
		client.setContactPhone2(phone2);

		if (this.client == null) {
			int newPersonID = personService.addRecord(client);
			if (newPersonID <= 0) {
				Tools.showAlert("There was a problem with creating person!");
				return;
			}
			client.setID(newPersonID);
			int newClientID = clientService.addRecord(client);
			if (newClientID <= 0) {
				Tools.showAlert("There was a problem with creating client!");
				return;
			}
			Tools.showInfo("Client Successfully Created");
			LoadClient(newClientID);
		} else {
			int res = personService.updateRecord(client, this.client.getID());
			if (res <= 0) {
				Tools.showAlert("There was a problem with updating person!");
				return;
			}
			client.setID(this.client.getID());
			res = clientService.updateRecord(client, this.client.getClientID());
			if (res <= 0) {
				Tools.showAlert("There was a problem with updating client!");
				return;
			}
			Tools.showInfo("Client Successfully updated");
			LoadClient(this.client.getClientID());
		}
	}

	@FXML
	void onCreateAccount(ActionEvent event) {
		AccountService accountService = new AccountService();

		int accountNo = Integer.parseInt(txtAcntNo.getText());
		String accountName = txtAcntName.getText();
		double balance = 0;
		int maturityOfSaving = Integer.parseInt(cboAcntMaturity.getValue().split(" - ")[0]);

		StringBuilder sb = new StringBuilder();
		if (accountNo == 0)
			sb.append("Account number cannot be empty" + System.lineSeparator());
		if (accountName.isEmpty())
			sb.append("Account name cannot be empty" + System.lineSeparator());

		if (sb.length() > 0) {
			Tools.showAlert(sb.toString());
			return;
		}

		Account account = null;
		if (cboAcntType.getValue().equals("1 - Checking")) {
			account = AccountFactory.createSavingAccount(accountNo, accountName, balance, false, maturityOfSaving,
					client);
		} else {
			account = AccountFactory.createCheckingAccount(accountNo, accountName, balance, false, client);
		}

		if (accountService.addRecord(account) == 0) {
			Tools.showAlert("Something wrong");
			return;
		}
		LoadClient(this.client.getClientID());
	}

	@FXML
	void onUserSave(ActionEvent event) {
		UserService userService = new UserService();
		User user = userService.getRecordByPerson(this.client.getID());

		String userName = txtUserName.getText();
		String userPass = txtUserPassword.getText();
		int userStatus = Integer.parseInt(cboUserStatus.getValue().split(" - ")[0]);

		StringBuilder sb = new StringBuilder();
		if (userName.isEmpty())
			sb.append("User name cannot be empty" + System.lineSeparator());
		if (userPass.isEmpty())
			sb.append("Password cannot be empty" + System.lineSeparator());

		if (sb.length() > 0) {
			Tools.showAlert(sb.toString());
			return;
		}

		int res = 0;
		if (user == null) {
			user = PersonFactory.createUser(this.client.getID(), "", "", "", 0, userName, userPass);
			user.setRoleID(2);
			user.setStatus(userStatus);
			user.setLastLoggedOn(LocalDate.now());
			res = userService.addRecord(user);
			// if newid <=0 no creation, otherwise returns new ID
		} else {
			user.setUserName(userName);
			user.setPassword(userPass);
			user.setStatus(userStatus);
			user.setLastLoggedOn(LocalDate.now());
			res = userService.updateRecord(user, user.getUserID());
			// <=0 means failure otherwise success
		}
		if (res <= 0) {
			Tools.showAlert("Something wrong");
			return;
		}
		Tools.showInfo("User saved");
		LoadClient(this.client.getClientID());
	}

	private Client client;
	private User user;
	private List<Account> accounts;

	public void LoadClient(int clientID) {

		ClientService clientService = new ClientService();
		this.client = clientService.getRecord(clientID);
		if (this.client == null)
			return;
		UserService userService = new UserService();
		this.user = userService.getRecordByPerson(this.client.getID());
		FilterListForAccount filter = new FilterListForAccount();
		filter.clientID = String.valueOf(this.client.getClientID());
		AccountService accountService = new AccountService();
		accounts = accountService.getAccounts(filter);
		FillForm();

		tabAccounts.setDisable(false);
		tabUser.setDisable(false);
	}

	private void FillForm() {
		if (client == null)
			return;
		txtLastName.setText(client.getLastName());
		txtMiddleName.setText(client.getMiddleName());
		txtFirstName.setText(client.getFirstName());
		dateBirth.setValue(client.getBirthDate());
		txtSSN.setText(client.getSSN());
		cboGender.setValue(client.getSex());
		txtEMail.setText(client.getEmailAddress());
		txtPhone.setText(client.getContactPhone());
		txtPhone2.setText(client.getContactPhone2());
		txtStreet.setText(client.getStreet());
		txtCity.setText(client.getCity());
		txtState.setText(client.getState());
		if (this.user != null) {
			txtUserName.setText(this.user.getUserName());
			txtUserPassword.setText(this.user.getPassword());
			lblUserLastLoggedOn
					.setText(this.user.getLastLoggedOn() != null ? this.user.getLastLoggedOn().toString() : "...");
			if (this.user.getStatus() == 1)
				cboUserStatus.setValue("1 - Active");
			else
				cboUserStatus.setValue("0 - Inactive");
		}
		if (this.accounts != null && this.accounts.size() > 0) {
			List<AcntListItem> tmpList = new ArrayList<>();
			for (Account acnt : this.accounts) {
				AcntListItem item = new AcntListItem();
				item.AcntNo = String.valueOf(acnt.getAccountNo());
				item.AcntName = String.valueOf(acnt.getAccountName());
				item.AcntType = acnt.getAccountType() == 2 ? "Savings" : "Checking";
				item.AcntMaturity = String.valueOf(acnt.getMaturityOfSaving());
				item.AcntBal = Tools.toMoneyStr(acnt.getBalance());

				tmpList.add(item);
			}
			ObservableList<AcntListItem> itemList = FXCollections.observableArrayList(tmpList);
			accountTable.setItems(itemList);
		}
	}

}
