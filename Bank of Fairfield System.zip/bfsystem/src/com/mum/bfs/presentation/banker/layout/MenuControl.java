package com.mum.bfs.presentation.banker.layout;

import java.io.IOException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import com.mum.bfs.presentation.banker.clientdetail.ClientControl;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuItem;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.*;

public class MenuControl {

	@FXML // fx:id="displayNewClient"
	private MenuItem displayNewClient; // Value injected by FXMLLoader

	@FXML // fx:id="displayClientsList"
	private MenuItem displayClientsList; // Value injected by FXMLLoader

	@FXML // fx:id="displayDeposit"
	private MenuItem displayDeposit; // Value injected by FXMLLoader

	@FXML // fx:id="displayWithdraw"
	private MenuItem displayWithdraw; // Value injected by FXMLLoader

	private Map<String, String> urls = new HashMap<>();

	private void callMenu(String str) {
		try {
			URL paneUrl = getClass().getResource(urls.get(str));
			Pane pane = FXMLLoader.load(paneUrl);

			BorderPane border = BankerMenu.getRoot();
			border.setCenter(pane);
			

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@FXML
	public void initialize() {
		urls.put("NewClient", "../clientdetail/PaneNewClient.fxml");
		urls.put("ClientsList", "../clientlist/PaneClientsList.fxml");
		urls.put("Deposit", "../trandeposit/PaneDeposit.fxml");
		urls.put("Withdraw", "../tranwithdraw/PaneWithdraw.fxml");
		urls.put("CreateAccount", "../account/PaneNewAccount.fxml");
	}

	/**
	 * Event handler for MenuItem New Client
	 */
	@FXML
	void switchToNewClient(ActionEvent event) {
		callMenu("NewClient");
	}

	/**
	 * Event handler for MenuItem Clients list
	 */
	@FXML
	void switchToClientsList(ActionEvent event) {
		callMenu("ClientsList");
	}

	/**
	 * Event handler for MenuItem Deposit
	 */
	@FXML
	void switchToDeposit(ActionEvent event) {
		callMenu("Deposit");
	}

	/**
	 * Event handler for MenuItem Withdraw
	 */
	@FXML
	void switchToWithdraw(ActionEvent event) {
		callMenu("Withdraw");
	}
	@FXML
	void switchToCreateAccount(ActionEvent event) {
		callMenu("CreateAccount");
	}
}
