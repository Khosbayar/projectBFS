package com.mum.bfs.presentation.banker.layout;

import java.io.IOException;
import java.net.URL;
import java.util.*;

import com.mum.bfs.business.models.*;
import com.mum.bfs.presentation.banker.clientlist.ClientListController;
import com.mum.bfs.presentation.client.home.homeController;
import com.mum.bfs.presentation.signin.FormSignIn;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.util.Pair;

public class Layout {
	@FXML
	Label lblConnUser;
	@FXML
	Label lblLastLoggedOn;
	@FXML
	MenuBar mainMenu;
	@FXML
	TabPane tabMain;

	private Map<String, Pair<String, String>> menuData = new HashMap<>();

	@FXML
	void initialize() {
		User connUser = FormSignIn.getConnUser();
		lblConnUser.setText(connUser.getUserName());
		lblLastLoggedOn.setText(connUser.getLastLoggedOn().toString());

		menuData.put("clientList", new Pair<String, String>("Client list", "../clientlist/PaneClientsList.fxml"));
		menuData.put("clientNew", new Pair<String, String>("Client detail", "../clientdetail/clientdetail.fxml"));
		menuData.put("tranDP", new Pair<String, String>("Deposit", "../trandeposit/PaneDeposit.fxml"));
		menuData.put("tranWD", new Pair<String, String>("Withdraw", "../tranwithdraw/PaneWithdraw.fxml"));
		// menuData.put("clientList", new Pair<String, String>("Client list",
		// "../clientlist/PaneClientsList.fxml"));
		// menuData.put("clientList", new Pair<String, String>("Client list",
		// "../clientlist/PaneClientsList.fxml"));
		menuData.put("accountList", new Pair<String, String>("Account list", "../accountList/PaneAccountsList.fxml"));
	}

	private void callMenu(String str) {
		try {
			URL paneUrl = getClass().getResource(menuData.get(str).getValue());

			FXMLLoader homeLoader = new FXMLLoader(paneUrl);
			Pane pane = homeLoader.load();
			if (str.equals("clientList")) {
				homeLoader.<ClientListController>getController().setTabPane(tabMain, menuData);
			}

			Tab tab = new Tab(menuData.get(str).getKey());
			tab.setContent(pane);
			tabMain.getTabs().add(tab);
			tabMain.getSelectionModel().select(tabMain.getTabs().size() - 1);

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@FXML
	void onMenuActionClientList(ActionEvent event) {
		callMenu("clientList");
	}

	@FXML
	void onMenuActionClientNew(ActionEvent event) {
		callMenu("clientNew");
	}

	@FXML
	void onMenuActionTranDP(ActionEvent event) {
		callMenu("tranDP");
	}

	@FXML
	void onMenuActionTranWD(ActionEvent event) {
		callMenu("tranWD");
	}

	@FXML
	void onMenuActionAccountList(ActionEvent event) {
		callMenu("accountList");
	}

	@FXML
	void onMenuActionControlReport(ActionEvent event) {

	}

	@FXML
	void onMenuActionControlEOD(ActionEvent event) {

	}
}
