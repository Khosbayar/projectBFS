package com.mum.bfs.presentation.banker.clientlist;

import java.io.IOException;
import java.net.URL;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import com.mum.bfs.business.models.Client;
import com.mum.bfs.business.services.ClientService;
import com.mum.bfs.presentation.banker.clientdetail.ClientDetail;
import com.mum.bfs.presentation.banker.layout.BankerMenu;
import com.mum.bfs.presentation.signin.FormSignIn;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.util.Pair;

public class ClientListController implements Initializable {
	@FXML private TableView<Client> clientListTable;
	@FXML private TableColumn<Client, String> lastNameColumn;
	@FXML private TableColumn<Client, String> middleNameColumn;
	@FXML private TableColumn<Client, String> firstNameColumn;
	@FXML private TextField searchTextField;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
//		ObservableList<Client> clients =
//		        FXCollections.observableArrayList(
//		        		PersonFactory.createClient(1, "matt", "john", "hog",2),
//		        		PersonFactory.createClient(11, "dave", "ken", "james",17),
//		        		PersonFactory.createClient(4, "ben", "tony", "smith",17)
//		        );
		
		ClientService cs = new ClientService();
		List<Client> c = cs.getAllClients();
		ObservableList<Client> clients = FXCollections.observableList(c);
			
		lastNameColumn.setMinWidth(100);
		lastNameColumn.setCellValueFactory(new PropertyValueFactory<Client, String>("LastName"));
	 
		middleNameColumn.setMinWidth(100);
		middleNameColumn.setCellValueFactory(new PropertyValueFactory<Client, String>("MiddleName"));
	 
		firstNameColumn.setMinWidth(100);
		firstNameColumn.setCellValueFactory(new PropertyValueFactory<Client, String>("FirstName"));
		
		FilteredList<Client> filteredClients = new FilteredList<>(clients, p -> true);
		searchTextField.textProperty().addListener((observable, oldValue, newValue) -> {
			filteredClients.setPredicate(client -> {
                if (newValue == null || newValue.isEmpty()) {
                    return true;
                }

                String lowerCaseFilter = newValue.toLowerCase();

                if (client.getLastName().toLowerCase().contains(lowerCaseFilter)) {
                    return true; 
                }
                else if (client.getMiddleName().toLowerCase().contains(lowerCaseFilter)) {
                    return true; 
                }
                else if (client.getFirstName().toLowerCase().contains(lowerCaseFilter)) {
                    return true;
                }
                return false; 
            });
        });
		SortedList<Client> sortedClients = new SortedList<>(filteredClients);
		sortedClients.comparatorProperty().bind(clientListTable.comparatorProperty());
		clientListTable.setItems(sortedClients);
		
//		Map<String, String> urls = new HashMap<>();
//		urls.put("NewClient", "../clientdetail/clientdetail.fxml");
//		
//		clientListTable.setRowFactory( tv -> {
//		    TableRow<Client> row = new TableRow<>();
//		    row.setOnMouseClicked(event -> {
//		        if (event.getClickCount() == 2 && (! row.isEmpty()) ) {
//		            Client rowData = row.getItem();
//		            System.out.println(rowData.getClientID());
//	
//		            try {
//		            		URL paneUrl = getClass().getResource(urls.get("NewClient"));
//		            		
//		            		Pane pane = FXMLLoader.load(paneUrl);
//                        Scene scene = new Scene(pane);
//                        Stage stage = new BankerMenu(FormSignIn.getPrimaryStage());
//                        stage.setScene(scene);
//
//                        stage.show();
//		    			} catch (IOException e) {
//		    				e.printStackTrace();
//		    			}
//
//		        	}
//		    });
//		    return row ;
//		});
		
		clientListTable.setRowFactory(tv -> {
			TableRow<Client> row = new TableRow<>();
			row.setOnMouseClicked(event -> {
				if (event.getClickCount() == 2 && (!row.isEmpty())) {
					Client rowData = row.getItem();

					
					try {
						URL paneUrl = getClass().getResource(menuData.get("clientNew").getValue());

						FXMLLoader homeLoader = new FXMLLoader(paneUrl);
						Pane pane = homeLoader.load();
						
						homeLoader.<ClientDetail>getController().LoadClient(rowData.getClientID());

						Tab tab = new Tab(menuData.get("clientNew").getKey());
						tab.setContent(pane);
						tabMain.getTabs().add(tab);
						tabMain.getSelectionModel().select(tabMain.getTabs().size() - 1);

					} catch (IOException e) {
						e.printStackTrace();
					}
					
				}
			});
			return row;
		});
		
		
	        
//		clientListTable.getItems().setAll(clients);
//        clientListTable.setItems(data);
//        clientListTable.getColumns().addAll(lastNameColumn, middleNameColumn, firstNameColumn);
	}
	

	private TabPane tabMain;
	private Map<String, Pair<String, String>> menuData;

	public void setTabPane(TabPane tabMain, Map<String, Pair<String, String>> menuData) {
		this.tabMain = tabMain;
		this.menuData = menuData;
	}

}
