package com.mum.bfs.presentation.banker.accountList;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

import com.mum.bfs.business.interfaces.Account;
import com.mum.bfs.business.models.AccountFactory;
import com.mum.bfs.business.models.Client;
import com.mum.bfs.business.models.PersonFactory;
import com.mum.bfs.business.services.AccountService;
import com.mum.bfs.tools.FilterListForAccount;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

public class AccountListController implements Initializable {
	@FXML
	private TableColumn<Account, String> lastNameColumn;
	@FXML
	private TableColumn<Account, String> middleNameColumn;
	@FXML
	private TableColumn<Account, String> firstNameColumn;
	@FXML
	private TableView<Account> accountListTable;
	@FXML
	private TableColumn<Account, String> accountNameColumn;
	@FXML
	private TableColumn<Account, String> accountNoColumn;
	@FXML
	private TableColumn<Account, String> accountBalanceColumn;
	@FXML
	private TableColumn<Account, String> PhoneNoColumn;
	@FXML
	private TableColumn<Account, String> emailAddressColumn;
	@FXML
	private TextField searchTextField;

	private AccountService as = new AccountService();

	@Override
	public void initialize(URL location, ResourceBundle resources) {

		FilterListForAccount f = new FilterListForAccount();
		List<Account> accList = as.getAccounts(f);

		ObservableList<Account> accounts = FXCollections.observableArrayList();
		for (Account acc : accList) {
			Account tmpA;
			if (acc.getAccountType() == 1) {
				tmpA = AccountFactory.createCheckingAccount(acc.getAccountNo(), acc.getAccountName(), acc.getBalance(),
						true, acc.getClient());
			} else {
				tmpA = AccountFactory.createSavingAccount(acc.getAccountNo(), acc.getAccountName(), acc.getBalance(),
						true, acc.getMaturityOfSaving(), acc.getClient());
			}
			accounts.add(tmpA);
		}
		FXCollections.observableList(accounts);
		lastNameColumn.setMinWidth(100);
		lastNameColumn.setCellValueFactory(new PropertyValueFactory<Account, String>("LastName"));

		middleNameColumn.setMinWidth(100);
		middleNameColumn.setCellValueFactory(new PropertyValueFactory<Account, String>("MiddleName"));

		firstNameColumn.setMinWidth(100);
		firstNameColumn.setCellValueFactory(new PropertyValueFactory<Account, String>("FirstName"));

		accountNameColumn.setMinWidth(100);
		accountNameColumn.setCellValueFactory(new PropertyValueFactory<Account, String>("accountName"));

		accountNoColumn.setMinWidth(100);
		accountNoColumn.setCellValueFactory(new PropertyValueFactory<Account, String>("accountNo"));

		accountBalanceColumn.setMinWidth(100);
		accountBalanceColumn.setCellValueFactory(new PropertyValueFactory<Account, String>("balance"));

		PhoneNoColumn.setMinWidth(100);
		PhoneNoColumn.setCellValueFactory(new PropertyValueFactory<Account, String>("phoneNumber"));

		emailAddressColumn.setMinWidth(100);
		emailAddressColumn.setCellValueFactory(new PropertyValueFactory<Account, String>("emailAddress"));

		FilteredList<Account> filteredAccounts = new FilteredList<>(accounts, p -> true);
		searchTextField.textProperty().addListener((observable, oldValue, newValue) -> {
			filteredAccounts.setPredicate(account -> {
				if (newValue == null || newValue.isEmpty()) {
					return true;
				}

				String lowerCaseFilter = newValue.toLowerCase();

				if (account.getAccountName().toLowerCase().contains(lowerCaseFilter)) {
					return true;
				} else if (account.getLastName().toLowerCase().contains(lowerCaseFilter)) {
					return true;
				} else if (account.getMiddleName().toLowerCase().contains(lowerCaseFilter)) {
					return true;
				} else if (account.getFirstName().toLowerCase().contains(lowerCaseFilter)) {
					return true;
				} else if (account.getEmailAddress().toLowerCase().contains(lowerCaseFilter)) {
					return true;
				} else if (account.getPhoneNumber().toLowerCase().contains(lowerCaseFilter)) {
					return true;
				} else if (Integer.toString(account.getAccountNo()).contains(newValue)) {
					return true;
				}
				return false;
			});
		});

		SortedList<Account> sortedAccounts = new SortedList<>(filteredAccounts);
		sortedAccounts.comparatorProperty().bind(accountListTable.comparatorProperty());
		accountListTable.setItems(sortedAccounts);
		// accountListTable.getItems().setAll(sortedAccounts);
	}
}
