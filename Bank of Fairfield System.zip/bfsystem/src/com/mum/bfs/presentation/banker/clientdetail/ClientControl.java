package com.mum.bfs.presentation.banker.clientdetail;

import java.net.URL;
import java.util.ResourceBundle;

import com.mum.bfs.business.models.Client;
import com.mum.bfs.business.models.PersonFactory;
import com.mum.bfs.business.services.ClientService;
import com.mum.bfs.tools.Tools;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

public class ClientControl {
	
	@FXML
	private TextField firstNameField;
	@FXML
	private TextField middleNameField;
	@FXML
	private TextField lastNameField;
	@FXML
	private TextField motherNameField;
	@FXML
	private TextField signatueField;
	@FXML
	private TextField photoUrlField;
	
	@FXML
	void addClient(ActionEvent event) {
		String name = firstNameField.getText();
		String middlename = middleNameField.getText();
		
		ClientService clientService = new ClientService();
		int ID = 3; 
		String LastName = "not matter";
		String MiddleName = "not matter";
		String FirstName = "not matter";
		String motherMaidenName = name;
		String signature = "C:\\hillarysignature.jpg";
		String photo = "C:\\hillaryphoto.jpg";
		
		int clientID = 0; // does not matter for now
		Client client = clientService.getRecordByPerson(1);
		client.setPhoto(photo);
		client.setSignature(signature);
		client.setMotherMaidenName(motherMaidenName);
		
		int res = clientService.addRecord(client);
		
		System.out.println(res);
		if(res ==0) {
			Tools.showAlert("There was a problem with creating client!");
			return;
		}
		Tools.showInfo("Client Successfully Created");
		clearFields();
	}
	
	void clearFields() {
		firstNameField.clear();
		middleNameField.clear();
		lastNameField.clear();
		motherNameField.clear();	
		signatueField.clear();
		photoUrlField.clear();
	}
}
