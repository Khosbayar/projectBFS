package com.mum.bfs.presentation.banker.account;

import com.mum.bfs.business.interfaces.Account;
import com.mum.bfs.business.models.AccountFactory;
import com.mum.bfs.business.models.Client;
import com.mum.bfs.business.models.PersonFactory;
import com.mum.bfs.business.services.AccountService;
import com.mum.bfs.business.services.ClientService;
import com.mum.bfs.tools.Tools;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;

public class AccountController {
	@FXML private TextField accountNameField;
	@FXML private TextField accountNoField;
	@FXML private TextField startingBalanceField;
	
	@FXML
	void addAccount() {
		String accountName = accountNameField.getText();
		String accountNo = accountNoField.getText();
		String startingBalance = startingBalanceField.getText();
		
		 ClientService cs = new ClientService();
		 Client client = cs.getRecord(1);
		 
		 AccountService a = new AccountService();
		 
		 Account act = AccountFactory.createCheckingAccount(Integer.parseInt(accountNo), accountName, 
				 Double.parseDouble(startingBalance), true, client);

		 int res = a.addRecord(act);
		 if(res ==0) {
			Tools.showAlert("Account could not be created, try again later!");
			
			return;
		 } 
		 Tools.showInfo("Account created!");
		 clearFields();
	}
	
	void clearFields() {
		accountNameField.clear();
		accountNoField.clear();
		startingBalanceField.clear();
	}

}
