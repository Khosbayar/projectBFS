package com.mum.bfs.presentation.banker.trandeposit;

public class AccountSelector {

}
