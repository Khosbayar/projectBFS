package com.mum.bfs.presentation.banker.layout;

import java.io.IOException;
import java.net.URL;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class BankerMenu extends Stage {

	// Creating a static root to pass to the controller
	private static BorderPane root;
//	private Stage primaryStage;

	public BankerMenu(Stage primaryStage) {
		root = new BorderPane();
		try {
			this.setTitle("BFS - Banker");
			this.setResizable(false);
			URL menuBarUrl = getClass().getResource("menus.fxml");
			MenuBar bar = FXMLLoader.load(menuBarUrl);

			root.setTop(bar);
			
			// root.setCenter(start);
			this.show();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	/**
	 * Just a root getter for the controller to use
	 */
	public static BorderPane getRoot() {
		return root;
	}

}
