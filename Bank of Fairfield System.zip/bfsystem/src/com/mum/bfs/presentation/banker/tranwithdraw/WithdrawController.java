package com.mum.bfs.presentation.banker.tranwithdraw;

import com.mum.bfs.business.services.TransactionService;
import com.mum.bfs.business.services.UserService;
import com.mum.bfs.tools.Result;
import com.mum.bfs.tools.Tools;

import javafx.fxml.FXML;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class WithdrawController {
	@FXML private TextField customerNameTextField;
	@FXML private TextField accountNoTextField;
	@FXML private TextField amountTextField;
	@FXML private TextField descriptionTextArea;

	
	@FXML
	void withdrawAmount() {
		System.out.println("Withdraw " + amountTextField.getText() + " from " + customerNameTextField.getText() + "'s account" );
		
		TransactionService ts = new TransactionService();
		
		Double tranAmount = Double.parseDouble(amountTextField.getText());
		String accountNo = accountNoTextField.getText();
		String accountName = customerNameTextField.getText();
		String desc = descriptionTextArea.getText();
		
		UserService userservice = new UserService();
		
		Result<Object> res = ts.doWithdraw(tranAmount, accountNo, accountName, desc, "Fairfield", userservice.getRecord(1));
		
		if(res.RetType !=0) {
			Tools.showAlert(res.RetDesc);
			return;
		}
		Tools.showInfo("Transaction is completed");
		clearFields();
	}
	
	void clearFields() {
		customerNameTextField.clear();
		accountNoTextField.clear();
		amountTextField.clear();
		descriptionTextArea.clear();	
	}
}
