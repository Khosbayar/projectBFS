package com.mum.bfs.presentation.banker.trandeposit;

import com.mum.bfs.business.services.TransactionService;
import com.mum.bfs.business.services.UserService;
import com.mum.bfs.tools.Result;
import com.mum.bfs.tools.Tools;

import javafx.fxml.FXML;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class TransactionController {
	@FXML private TextField customerNameTextField;
	@FXML private TextField accountNoTextField;
	@FXML private TextField amountTextField;
	@FXML private TextField descriptionTextArea;
	
	
	@FXML
	void makeDeposit() {
		System.out.println("Deposit " + amountTextField.getText() + " into " + customerNameTextField.getText() + "'s account" );
		TransactionService ts = new TransactionService();
		
		Double tranAmount = Double.parseDouble(amountTextField.getText());
		String accountNo = accountNoTextField.getText();
		String accountName = customerNameTextField.getText();
		String desc = descriptionTextArea.getText();
		
		UserService userservice = new UserService();
		
		Result<Object> res = ts.doDeposit(tranAmount, accountNo, accountName, desc, "Fairfield", userservice.getRecord(1));
		if(res.RetType !=0) {
			Tools.showAlert(res.RetDesc);
			return;
		}
		Tools.showInfo("Transaction is completed");
		clearFields();
	}
	
	@FXML
	void findAccount() {
		
	}
	
	protected String getCustName() {
		return customerNameTextField.getText();
	}
	
	protected String getAccountNo() {
		return accountNoTextField.getText();
	}
	
	protected String getAmount() {
		return amountTextField.getText();
	}
	
	protected String getDesc() {
		return descriptionTextArea.getText();
	}
	
	void clearFields() {
		customerNameTextField.clear();
		accountNoTextField.clear();
		amountTextField.clear();
		descriptionTextArea.clear();	
	}
}
