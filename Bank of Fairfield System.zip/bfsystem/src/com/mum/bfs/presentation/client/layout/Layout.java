package com.mum.bfs.presentation.client.layout;

import java.io.IOException;
import java.net.*;

import com.mum.bfs.presentation.client.home.homeController;
import com.mum.bfs.presentation.client.transfer.Transfer;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class Layout {
	@FXML
	Tab ContentHome;
	@FXML
	Tab ContentTransfer;
	@FXML
	Tab ContentSettings;
	@FXML
	Tab ContentInfo;
	@FXML
	TabPane tabPane;
	
	public homeController homeCtrl;

	public Transfer transferCtrl;

	@FXML
	public void initialize() {
		// Will be called by FXMLLoader
		try {
			FXMLLoader homeLoader = new FXMLLoader(
					getClass().getResource("/com/mum/bfs/presentation/client/home/home.fxml"));
			ContentHome.setContent(homeLoader.load());
			this.homeCtrl = homeLoader.<homeController>getController();
			homeCtrl.setTabPane(tabPane);
			
			

			FXMLLoader transferLoader = new FXMLLoader(
					getClass().getResource("/com/mum/bfs/presentation/client/transfer/transfer.fxml"));
			ContentTransfer.setContent(transferLoader.load());
			this.transferCtrl = transferLoader.<Transfer>getController();
			this.transferCtrl.setLayoutController(this);
			
			ContentSettings.setContent(FXMLLoader.load(
					getClass().getResource("/com/mum/bfs/presentation/client/changepassword/changepassword.fxml")));
			ContentInfo.setContent(FXMLLoader.load(
					getClass().getResource("/com/mum/bfs/presentation/client/clientinfo/clientinfo.fxml")));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
