package com.mum.bfs.presentation.client.home;

import java.io.IOException;
import java.util.List;

import com.mum.bfs.business.interfaces.Account;
import com.mum.bfs.business.models.*;
import com.mum.bfs.business.services.*;
import com.mum.bfs.presentation.signin.FormSignIn;
import com.mum.bfs.tools.FilterListForAccount;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.*;
import javafx.scene.layout.*;

public class homeController {

	@FXML
	VBox accountsSavings;
	@FXML
	VBox accountsChecking;
	@FXML
	Label lblUserName;
	@FXML
	Label lblLastSignedIn;

	public static List<Account> accounts;

	@FXML
	public void initialize() {
		User connUser = FormSignIn.getConnUser();
		lblUserName.setText(connUser.getUserName());
		lblLastSignedIn.setText(connUser.getLastLoggedOn().toString());
		refreshAccounts();
	}

	public void refreshAccounts() {
		accountsSavings.getChildren().clear();
		accountsChecking.getChildren().clear();
		if (accounts != null) {
			accounts.clear();
		}
		User connUser = FormSignIn.getConnUser();

		ClientService cs = new ClientService();
		Client client = cs.getRecordByPerson(connUser.getID());

		AccountService as = new AccountService();
		FilterListForAccount filter = new FilterListForAccount();
		filter.clientID = String.format("%d", client.getClientID()) ;
		accounts = as.getAccounts(filter);

		for (Account account : accounts) {
			if (account.getAccountType() == 2)
				accountsSavings.getChildren().add(createNewAcntItem(account));
			if (account.getAccountType() == 1)
				accountsChecking.getChildren().add(createNewAcntItem(account));
		}
	}

	private Pane createNewAcntItem(Account account) {
		Pane acntItemPane = null;
		try {
			FXMLLoader loader = new FXMLLoader(
					getClass().getResource("/com/mum/bfs/presentation/client/home/acntItem.fxml"));
			acntItemPane = loader.load();
			acntItemController ctrl = loader.<acntItemController>getController();
			ctrl.setValues(account);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return acntItemPane;
	}

	TabPane tabPane;

	public void setTabPane(TabPane tabPane) {
		this.tabPane = tabPane;
	}

	@FXML
	protected void btnMoreAction(ActionEvent event) {
		tabPane.getSelectionModel().select(3);
	}
}
