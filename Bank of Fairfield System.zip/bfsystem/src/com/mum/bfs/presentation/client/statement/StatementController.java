package com.mum.bfs.presentation.client.statement;

import java.io.IOException;
import java.util.List;

import com.mum.bfs.business.interfaces.Account;
import com.mum.bfs.business.interfaces.Transaction;
import com.mum.bfs.business.services.TransactionService;
import com.mum.bfs.presentation.client.home.acntItemController;
import com.mum.bfs.tools.Tools;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;

public class StatementController {

	@FXML
	Label lblAcntNo;
	@FXML
	Label lblAvailableBalance;
	@FXML
	VBox vboxStatItems;

	@FXML
	DatePicker fromDate;
	@FXML
	DatePicker toDate;

	@FXML
	Button searchBtn;

	private Account account;

	public void SetAcnt(Account account) {
		this.account = account;
		lblAcntNo.setText(String.valueOf(account.getAccountNo() + " - " + account.getAccountName()));
		lblAvailableBalance.setText(Tools.toMoneyStr(account.getBalance()));
	}

	@FXML
	void searchBtnAction(ActionEvent event) {
		StringBuilder sb = new StringBuilder();
		if (fromDate.getValue() == null) {
			sb.append("Choose start date" + System.lineSeparator());
		}
		if (toDate.getValue() == null) {
			sb.append("Choose end date" + System.lineSeparator());
		}
		if (sb.length() > 0) {
			Tools.showAlert(sb.toString());
			return;
		}
		if (fromDate.getValue().isAfter(toDate.getValue())) {
			sb.append("End date cannot less than start date" + System.lineSeparator());
		}
		if (sb.length() > 0) {
			Tools.showAlert(sb.toString());
			return;
		}

		vboxStatItems.getChildren().clear();
		try {
			TransactionService ts = new TransactionService();
			List<Transaction> trans = ts.getTransactionHistory(fromDate.getValue(), toDate.getValue(),
					account.getAccountNo());

			for (Transaction tran : trans) {
				FXMLLoader loader = new FXMLLoader(
						getClass().getResource("/com/mum/bfs/presentation/client/statement/statItem.fxml"));
				Pane statItemPane = loader.load();
				vboxStatItems.getChildren().add(statItemPane);

				StateItem ctrl = loader.<StateItem>getController();
				
				double amt = tran.getTranAmount();
				if(tran.getFromAccountNo().getAccountNo() == account.getAccountNo()) {
					amt = -amt;
				}
				
				ctrl.setData(tran.getTranDate().toString(), tran.getTransactionDescription(), amt);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
