package com.mum.bfs.presentation.client.transfer;

import com.mum.bfs.business.interfaces.Account;
import com.mum.bfs.business.services.TransactionService;
import com.mum.bfs.presentation.client.home.homeController;
import com.mum.bfs.presentation.client.layout.Layout;
import com.mum.bfs.presentation.signin.FormSignIn;
import com.mum.bfs.tools.Result;
import com.mum.bfs.tools.Tools;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.util.Pair;

public class Transfer {
	@FXML
	ComboBox<String> cboFrom;
	@FXML
	TextField txtToAcntNo;
	@FXML
	TextField txtToAcntName;
	@FXML
	TextField txtAmt;
	@FXML
	TextField txtDesc;

	@FXML
	public void initialize() {
		cboFrom.getItems().clear();
		for (Account account : homeController.accounts) {
			cboFrom.getItems()
					.add(String.valueOf(account.getAccountNo()) + " - " + Tools.toMoneyStr(account.getBalance()));
		}
		cboFrom.getSelectionModel().selectFirst(); // Select first as default
	}
	private Layout layoutController;
	public void setLayoutController(Layout layoutController) {
		this.layoutController =  layoutController;
	}

	@FXML
	void btnSendAction(ActionEvent event) {
		StringBuilder sb = new StringBuilder();
		if (cboFrom.getValue().isEmpty()) {
			sb.append("Choose an account" + System.lineSeparator());
		}
		if (txtToAcntNo.getText().trim().isEmpty()) {
			sb.append("Insert reciever account" + System.lineSeparator());
		}
		if (txtToAcntName.getText().trim().isEmpty()) {
			sb.append("Insert reciever name" + System.lineSeparator());
		}
		if (txtAmt.getText().trim().isEmpty()) {
			sb.append("Insert transaction amount" + System.lineSeparator());
		}
		if (txtDesc.getText().trim().isEmpty()) {
			sb.append("Insert description" + System.lineSeparator());
		}
		if (sb.length() > 0) {
			Tools.showAlert(sb.toString());
			return;
		}

		String fromAcntNo = (cboFrom.getValue().split("-")[0].trim());
		String toAcntNo = (txtToAcntNo.getText().trim());
		String toAcntName = txtToAcntName.getText().trim();
		double amt = Double.parseDouble(txtAmt.getText().trim());
		String desc = txtDesc.getText().trim();
		
		TransactionService ts = new TransactionService();
		Result<Object> res = ts.doTransfer(amt, fromAcntNo, toAcntNo, toAcntName, desc, "ONLINE", FormSignIn.getConnUser());
		if(res.RetType != 0) {
			Tools.showAlert(res.RetDesc);
			return;
		}
		Tools.showInfo("Your transaction is completed.");
		
		txtToAcntNo.clear();
		txtToAcntName.clear();
		txtAmt.clear();
		txtDesc.clear();
		
		layoutController.homeCtrl.refreshAccounts();
		initialize();
		return;
		
	}
}
