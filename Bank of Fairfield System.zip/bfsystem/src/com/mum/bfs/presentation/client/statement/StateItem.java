package com.mum.bfs.presentation.client.statement;

import com.mum.bfs.tools.Tools;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.paint.Color;

public class StateItem {
	@FXML
	Label lblTranDate;
	@FXML
	Label lblTranDesc;
	@FXML
	Label lblTranAmount;

	public void setData(String tranDate, String tranDesc, String amount) {
		lblTranDate.setText(tranDate);
		lblTranDesc.setText(tranDesc);
		double amt = Double.valueOf(amount);
		lblTranAmount.setText(Tools.toMoneyStr(amt));
		if (amt < 0) {
			lblTranAmount.setTextFill(Color.RED);
		} else {
			lblTranAmount.setTextFill(Color.GREEN);
		}
	}

	public void setData(String tranDate, String tranDesc, double amount) {
		setData(tranDate, tranDesc, String.valueOf(amount));
	}

}
