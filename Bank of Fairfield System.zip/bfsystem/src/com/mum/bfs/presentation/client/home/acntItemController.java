package com.mum.bfs.presentation.client.home;

import java.io.IOException;
import java.text.NumberFormat;

import com.mum.bfs.business.interfaces.Account;
import com.mum.bfs.presentation.client.statement.StatementController;
import com.mum.bfs.tools.Tools;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonBar.ButtonData;
import javafx.util.Pair;

public class acntItemController {

	@FXML
	Label lblAcntNo;
	@FXML
	Label lblAvailableBalance;

	private Account account;
	public void setValues(Account account) {
		this.account = account;
		lblAcntNo.setText(String.valueOf(account.getAccountNo()));
		lblAvailableBalance.setText(Tools.toMoneyStr(account.getBalance()));
	}

	@FXML
	void btnMoreAction(ActionEvent event) {
		
		// Create the custom dialog.
		Dialog<Pair<String, String>> dialog = new Dialog<>();
		dialog.setTitle("Account transactions");
		dialog.setHeaderText(null);

		dialog.getDialogPane().getButtonTypes().addAll(ButtonType.CANCEL);
		
		FXMLLoader loader = new FXMLLoader(
				getClass().getResource("/com/mum/bfs/presentation/client/statement/statement.fxml"));
		try {
			dialog.getDialogPane().setContent(loader.load());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		StatementController ctrl = loader.<StatementController>getController();
		ctrl.SetAcnt(account);
		dialog.showAndWait();
	}

}
