package com.mum.bfs.presentation.client.changepassword;

import com.mum.bfs.business.models.User;
import com.mum.bfs.business.services.UserService;
import com.mum.bfs.presentation.signin.FormSignIn;
import com.mum.bfs.tools.Tools;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;

public class ChangePassword {
	@FXML
	TextField txtCurrent;
	@FXML
	TextField txtNew;
	@FXML
	TextField txtRepeat;

	@FXML
	void btnSave(ActionEvent event) {
		StringBuilder sb = new StringBuilder();

		if (txtCurrent.getText().isEmpty()) {
			sb.append("Current password cannot be empty" + System.lineSeparator());
		}
		if (txtNew.getText().isEmpty()) {
			sb.append("New password cannot be empty" + System.lineSeparator());
		}
		if (!txtNew.getText().equals(txtRepeat.getText())) {
			sb.append("Repeated password is not same as new password" + System.lineSeparator());
		}

		if (sb.length() > 0) {
			Tools.showAlert(sb.toString());
			return;
		}
		

		if (txtNew.getText().length() < 6 ) {
			Tools.showAlert("Password minimum length is 6");
			return;
		}
		
		User user = FormSignIn.getConnUser();
		if (!txtCurrent.getText().equals(user.getPassword())) {
			Tools.showAlert("Current password is wrong");
			return;
		}
		UserService userservice = new UserService();
		user.setPassword(txtNew.getText());
		userservice.updateRecord(user, user.getID());
		Tools.showInfo("Password has changed.");
		
		txtCurrent.clear();
		txtNew.clear();
		txtRepeat.clear();
	}
}
