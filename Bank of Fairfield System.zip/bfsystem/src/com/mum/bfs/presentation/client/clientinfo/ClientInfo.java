package com.mum.bfs.presentation.client.clientinfo;

import java.io.IOException;

import com.mum.bfs.business.models.User;
import com.mum.bfs.presentation.signin.FormSignIn;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.layout.*;

public class ClientInfo {

	@FXML
	VBox vboxPane;

	@FXML
	public void initialize() {

		User connUser = FormSignIn.getConnUser();
		vboxPane.getChildren().add(createItem("User:", connUser.getUserName()));
		vboxPane.getChildren().add(createItem("Last logged on:", connUser.getLastLoggedOn().toString()));
		vboxPane.getChildren().add(createItem("First name:", connUser.getFirstName()));
		vboxPane.getChildren().add(createItem("Last name:", connUser.getLastName()));
		vboxPane.getChildren().add(createItem("Middle name:", connUser.getMiddleName()));
		vboxPane.getChildren().add(createItem("Birth:", connUser.getBirthDate().toString()));
		vboxPane.getChildren().add(createItem("Contact phone:", connUser.getContactPhone()));
		vboxPane.getChildren().add(createItem("E-mail:", connUser.getEmailAddress()));
		vboxPane.getChildren().add(createItem("Address:", connUser.getAddress()));
		vboxPane.getChildren().add(createItem("Gender:", connUser.getSex()));
		vboxPane.getChildren().add(createItem("SSN:", connUser.getSSN()));

	}

	private Pane createItem(String key, String value) {
		Pane acntItemPane = null;
		try {
			FXMLLoader loader = new FXMLLoader(
					getClass().getResource("/com/mum/bfs/presentation/client/clientinfo/infoItem.fxml"));
			acntItemPane = loader.load();
			InfoItem ctrl = loader.<InfoItem>getController();
			ctrl.setData(key, value);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return acntItemPane;
	}

}
