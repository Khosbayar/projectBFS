package com.mum.bfs.presentation.client.clientinfo;

import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class InfoItem {
	@FXML
	Label lblKey;
	@FXML
	Label lblValue;
	
	public void setData(String key, String value) {
		lblKey.setText(key);
		lblValue.setText(value);
	}
}
