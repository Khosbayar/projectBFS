package com.mum.bfs.tools;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.time.*;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.Image;
import javafx.stage.Stage;

import java.sql.*;

public class Tools {

	public static void closeResultSet(ResultSet rs) {
		// ResultSet
		try {
			if (rs != null) {
				rs.close();
				rs = null;
			}
		} catch (SQLException sqle) {
			Printer.printSQLException(sqle);
		}
	}

	public static void setStageIcon(Stage stage) {
		stage.getIcons().add(new Image("/com/mum/bfs/presentation/signin/stackoverflow.png"));
	}

	public static void showAlert(String txt) {
		Alert alert = new Alert(AlertType.ERROR);
		alert.setTitle("Oops...");
		alert.setHeaderText("We are sorry! There is something wrong. :)");
		alert.setContentText(txt);

		alert.showAndWait();
	}

	public static void showInfo(String txt) {
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setTitle("Information");
		// alert.setHeaderText("Look, an Information Dialog");
		alert.setContentText(txt);

		alert.showAndWait();
	}

	public static String toMoneyStr(String val) {
		return toMoneyStr(Double.valueOf(val));
	}

	public static String toMoneyStr(double val) {
		DecimalFormat df = new DecimalFormat("#,###,###,##0.00");
		String moneyString = df.format(val);
		return "$" + moneyString;
	}
}
