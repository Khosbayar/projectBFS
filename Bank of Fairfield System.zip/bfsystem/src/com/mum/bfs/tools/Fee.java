package com.mum.bfs.tools;

public enum Fee {
	onlineTransaction(0.2), onlineWithdraw(0.1), withdraw(0.5), savingBookFee(1), maintenanceFee(3);

	private final double amount;

	Fee(double amount) {
		this.amount = amount;
	}

	public double getAmount() {
		return amount;
	}
}
