package com.mum.bfs.tools;

public class AcntListItem {
	public String AcntNo;
	public String AcntName;
	public String AcntType;
	public String AcntMaturity;
	public String AcntBal;
	
	public String getAcntNo() {
		return AcntNo;
	}
	public String getAcntName() {
		return AcntName;
	}

	public String getAcntType() {
		return AcntType;
	}

	public String getAcntMaturity() {
		return AcntMaturity;
	}

	public String getAcntBal() {
		return AcntBal;
	}


}
