package com.mum.bfs.tools;

public class FilterListForAccount {
	public String personName = null;
	public String accountID = null;
	public String phoneNumber = null;
	public String email = null;
	public String clientID = null;
}
