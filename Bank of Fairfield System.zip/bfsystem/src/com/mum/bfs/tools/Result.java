package com.mum.bfs.tools;

public class Result<T> {
	// 0-WORKED
	// !0 - Error occured
	public int RetType;
	public String RetDesc;
	public T RetData;

	public Result() {
		this(0);
	}

	public Result(int retType) {
		this(retType, "");
	}

	public Result(int retType, String retDesc) {
		this.RetType = retType;
		this.RetDesc = retDesc;
	}

	public Result(T data) {
		this.RetType = 0;
		this.RetDesc = "";
		this.RetData = data;
	}
}
