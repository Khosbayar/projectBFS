package com.mum.bfs.dataaccess;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {
	
	public static final String DB_DRIVER = new String("org.sqlite.JDBC");
	public static final String DB_URL = new String("jdbc:sqlite:BFSystem.db");
	
	private Connection connection;
	
	private static DBConnection instance = new DBConnection();
	
	private DBConnection() {
		try {
			// Connect to DB
			System.out.println("Loading the SQLite jdbc driver...");
			Class.forName(DB_DRIVER).newInstance();
		
			System.out.println("Connecting to the BFSystem database on SQLite server...");
			connection = DriverManager.getConnection(DB_URL);
			System.out.println("Successfully made the connection to BFSystem DB.");
		} catch(Exception ex) {
			System.out.println(ex);
			ex.printStackTrace();
		}
	}
	
	public static DBConnection getInstance() {
		return instance;
	}
	
	public Connection getConnection() {
		return connection;
	}

}

