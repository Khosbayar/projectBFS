package com.mum.bfs.dataaccess;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.time.LocalDate;

import com.mum.bfs.business.models.User;
import com.mum.bfs.tools.Printer;
import com.mum.bfs.tools.Tools;

import java.util.*;

public class DBProvider {

	private DBConnection dbConnection;
	
	public DBProvider()
	{
		this.dbConnection = DBConnection.getInstance();
	}
	
	public HashMap<String,String> getRow(String SQL, HashMap<Integer,String> params)
	{
	Connection conn = dbConnection.getConnection();
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	HashMap<String,String> results = new HashMap<String,String>();
	
	try {
		
		pstmt = conn.prepareStatement(SQL);
		
		for (Map.Entry<Integer, String> param : params.entrySet()) 
		{
		    Integer key = param.getKey();
		    String value = param.getValue();
		    pstmt.setString(key, value);
		}
		
		rs = pstmt.executeQuery();
		
		rs.next();
	 	
		 ResultSetMetaData rsMetaData = rs.getMetaData();
	     int count = rsMetaData.getColumnCount();
	     
	     for(int i=1;i<=count;i++)
	     {
	    	 String columnName = rsMetaData.getColumnName(i);
	    	 String value = rs.getString(i);
	    	 results.put(columnName, value);
	     }
		
	    Tools.closeResultSet(rs);
	     
		return results;
		
	} catch(SQLException sqlEx) {
		Printer.printSQLException(sqlEx);
	} finally {
        // release resources
        try {
            if (pstmt != null) {
            	pstmt.close();
            	pstmt = null;
            }
        } catch (SQLException sqle) {
            Printer.printSQLException(sqle);
        }
    }
	
	return results;

}
	public int addUpdateRow(String SQL, HashMap<Integer,String> params)
	{
		Connection conn = dbConnection.getConnection();
		PreparedStatement pstmt = null;
		int result = 0;
		
		try {
			pstmt = conn.prepareStatement(SQL);
	
			for (Map.Entry<Integer, String> param : params.entrySet()) 
			{
			    Integer key = param.getKey();
			    String value = param.getValue();
			    pstmt.setString(key, value);
			}
			
			result = pstmt.executeUpdate();
			
		} catch(SQLException sqlEx) {
			Printer.printSQLException(sqlEx);
		} finally {
            // release resources
            try {
                if (pstmt != null) {
                	pstmt.close();
                	pstmt = null;
                }
            } catch (SQLException sqle) {
                Printer.printSQLException(sqle);
            }
        }
		
		return result;
	
	}
	
	public int getNextID(String SQL)
	{
		Connection conn = dbConnection.getConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int result = 0;
		
		try {
			pstmt = conn.prepareStatement(SQL);
			rs = pstmt.executeQuery();
			rs.next();
		    result = rs.getInt("nextID");
		    Tools.closeResultSet(rs);
		} catch(SQLException sqlEx) {
			Printer.printSQLException(sqlEx);
		} finally {
            // release resources
            try {
                if (pstmt != null) {
                	pstmt.close();
                	pstmt = null;
                }
            } catch (SQLException sqle) {
                Printer.printSQLException(sqle);
            }
        }
		
		return result;
	
	}
	
	public List<HashMap<String,String>> getMultipleRows(String SQL, HashMap<Integer,String> params)
	{
	Connection conn = dbConnection.getConnection();
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	List<HashMap<String,String>> results = new ArrayList<HashMap<String,String>>();
	
	try {
		
		pstmt = conn.prepareStatement(SQL);
		
		for (Map.Entry<Integer, String> param : params.entrySet()) 
		{
		    Integer key = param.getKey();
		    String value = param.getValue();
		    pstmt.setString(key, value);
		}
		
		rs = pstmt.executeQuery();
		
		while(rs.next()) {
			 ResultSetMetaData rsMetaData = rs.getMetaData();
		     int count = rsMetaData.getColumnCount();
		     HashMap<String,String> resultrow = new HashMap<String,String>();
		     for(int i=1;i<=count;i++)
		     {
		    	 String columnName = rsMetaData.getColumnName(i);
		    	 String value = rs.getString(i);
		    	 resultrow.put(columnName, value);
		     }
		     results.add(resultrow);
		}
		
	  Tools.closeResultSet(rs);
	     
		return results;
		
	} catch(SQLException sqlEx) {
		Printer.printSQLException(sqlEx);
	} finally {
        // release resources
        try {
            if (pstmt != null) {
            	pstmt.close();
            	pstmt = null;
            }
        } catch (SQLException sqle) {
            Printer.printSQLException(sqle);
        }
    }
	
	return results;

}

	
}
	

