package com.mum.bfs.business.interfaces;


public interface IService<T> {

	public int addRecord(T object);
	public T getRecord(int ID);
	public int updateRecord(T object, int ID);
	public void deleteRecord(int ID);
	public int getNextID();
	
	
}
