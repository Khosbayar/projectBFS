package com.mum.bfs.business.interfaces;

import java.time.LocalDate;
import java.time.LocalDateTime;

import com.mum.bfs.business.models.User;

public abstract class Transaction {

	private LocalDateTime tranDate;
	private double tranAmount;
	private Account fromAccountNo;
	private Account toAccountNo;
	private double startBalance;
	private double endBalance;
	private String transactionDescription;
	private String location;
	private User createdBy;
	private int tranType;

	protected Transaction(double tranAmount, Account fromAccountNo, Account toAccountNo, String transactionDescription,
			String location, User createdBy) {
		this.tranDate = LocalDateTime.now();
		this.tranAmount = tranAmount;
		this.fromAccountNo = fromAccountNo;
		this.toAccountNo = toAccountNo;
		this.transactionDescription = transactionDescription;
		this.location = location;
		this.createdBy = createdBy;
	}

	public abstract boolean addTransaction();

	// public int getTranId() {
	// return tranId;
	// }
	//
	// public void setTranId(int tranId) {
	// this.tranId = tranId;
	// }

	public LocalDateTime getTranDate() {
		return tranDate;
	}

	public void setTranDate(LocalDateTime tranDate) {
		this.tranDate = tranDate;
	}

	public double getTranAmount() {
		return tranAmount;
	}

	public void setTranAmount(double tranAmount) {
		this.tranAmount = tranAmount;
	}

	public Account getFromAccountNo() {
		return fromAccountNo;
	}

	public void setFromAccountNo(Account fromAccountNo) {
		this.fromAccountNo = fromAccountNo;
	}

	public Account getToAccountNo() {
		return toAccountNo;
	}

	public void setToAccountNo(Account toAccountNo) {
		this.toAccountNo = toAccountNo;
	}

	public double getStartBalance() {
		return startBalance;
	}

	public void setStartBalance(double startBalance) {
		this.startBalance = startBalance;
	}

	public double getEndBalance() {
		return endBalance;
	}

	public void setEndBalance(double endBalance) {
		this.endBalance = endBalance;
	}

	public String getTransactionDescription() {
		return transactionDescription;
	}

	public void setTransactionDescription(String transactionDescription) {
		this.transactionDescription = transactionDescription;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public User getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(User createdBy) {
		this.createdBy = createdBy;
	}

	public int getTranType() {
		return tranType;
	}

	public void setTranType(int tranType) {
		this.tranType = tranType;
	}

}
