package com.mum.bfs.business.interfaces;

import java.time.*;

public abstract class Person {
	
	private int ID;
	private String LastName;
	private String MiddleName;
	private String FirstName;
	private LocalDate BirthDate;
	private String ContactPhone;
	private String EmailAddress;
	private String ContactPhone2;
	private String 	No;
	private String 	Street;
	private String 	City;
	private String 	State;
	private String 	Zip;
	private String 	Sex;
	private String 	SSN;
	
    protected Person(int ID,String LastName,String MiddleName, String FirstName)
    {
    	this.ID = ID;
    	this.LastName = LastName;
    	this.MiddleName = MiddleName;
    	this.FirstName = FirstName;
    }
	
	public int getID()
	{
		return this.ID;
	}
	
	public void setID(int PersonID)
	{
		this.ID = PersonID;
	}
	
	public String getLastName()
	{
		return this.LastName;
	}
	
	public void setLastName(String LastName)
	{
		this.LastName = LastName;
	}

	public String getMiddleName()
	{
		return this.MiddleName;
	}
	
	public void setMiddleName(String MiddleName)
	{
		this.MiddleName = MiddleName;
	}
	
	public String getFirstName()
	{
		return this.FirstName;
	}
	
	public void setFirstName(String FirstName)
	{
		this.FirstName = FirstName;
	}
	
	public LocalDate getBirthDate()
	{
		return this.BirthDate;
	}
	
	public void setBirthDate(LocalDate BirthDate)
	{
		this.BirthDate = BirthDate;
	}
	
	public String getContactPhone()
	{
		return this.ContactPhone;
	}
	
	public void setContactPhone(String ContactPhone)
	{
		this.ContactPhone = ContactPhone;
	}
	
	public String getContactPhone2()
	{
		return this.ContactPhone2;
	}
	
	public void setContactPhone2(String ContactPhone2)
	{
		this.ContactPhone2 = ContactPhone2;
	}
	
	public String getEmailAddress()
	{
		return this.EmailAddress;
	}
	
	public void setEmailAddress(String EmailAddress)
	{
		this.EmailAddress = EmailAddress;
	}
	
	public String getSex()
	{
		return this.Sex;
	}
	
	public void setSex(String Sex)
	{
		this.Sex = Sex;
	}

	public String getSSN()
	{
		return this.SSN;
	}
	
	public void setSSN(String SSN)
	{
		this.SSN = SSN;
	}
	
	public String getNo()
	{
		return this.No;
	}
	
	public void setNo(String No)
	{
		this.No = No;
	}
	
	public String getStreet()
	{
		return this.Street;
	}
	
	public void setStreet(String Street)
	{
		this.Street = Street;
	}
	
	public String getCity()
	{
		return this.City;
	}
	
	public void setCity(String City)
	{
		this.City = City;
	}
	
	public String getState()
	{
		return this.State;
	}
	
	public void setState(String State)
	{
		this.State = State;
	}
	
	public String getZip()
	{
		return this.Zip;
	}
	
	public void setZip(String Zip)
	{
		this.Zip = Zip;
	}
	
	public void setAddress(String No, String Street, String City, String State, String Zip)
	{
		this.No = No;
		this.Street = Street;
		this.City = City;
		this.State = State;
		this.Zip = Zip;
	}
	
	public String getAddress()
	{
      return String.format("%s %s %s, %s %s", this.No,this.Street,this.City,this.State,this.Zip);		
	}
	
	public abstract String displayName();

}
