package com.mum.bfs.business.interfaces;

import java.time.LocalDate;
import com.mum.bfs.business.models.*;

public abstract class Account {
	private int accountNo;
	private String accountName;
	private LocalDate openedDate;
	private double balance;
	private double interestRate;
	private double minimumBalance;
	private int accountStatus;
	private boolean isBankAccount;
	private Client client;

	protected Account(int accountNo, String accountName, double balance, boolean isBankAccount, Client client) {
		this.accountNo = accountNo;
		this.accountName = accountName;
		this.openedDate = LocalDate.now();
		this.isBankAccount = isBankAccount;
		this.accountStatus = 1;
		this.balance = balance;
		this.client = client;
	}

	public void setClient(Client client) {
		this.client = client;

	}

	public void setInterestRate(double interestRate) {
		this.interestRate = interestRate;
	}

	public void setMinimumBalance(double minimumBalalnce) {
		this.minimumBalance = minimumBalalnce;
	}

	public boolean checkBalance(double checkAmount) {
		return (balance-minimumBalance >= checkAmount);
	}

	public Account getAccountDetails() {
		return this;
	}

	public abstract int getAccountType();

	public abstract double getMaintenanceFee();

	public abstract double getSavingBookFee();

	public abstract int getMaturityOfSaving();

	// Getters
	public int getAccountNo() {
		return accountNo;
	}

	public String getAccountName() {
		return accountName;
	}

	public LocalDate getOpenedDate() {
		return openedDate;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public double getInterestRate() {
		return interestRate;
	}

	public double getMinimumBalance() {
		return minimumBalance;
	}

	public int getAccountStatus() {
		return accountStatus;
	}

	public boolean isBankAccount() {
		return isBankAccount;
	}

	public Client getClient() {
		return client;
	}

	public void setOpenedDate(LocalDate openedDate) {
		// TODO Auto-generated method stub
		this.openedDate = openedDate;
	}

	public void setAccountStatus(int accountStatus) {
		// TODO Auto-generated method stub
		this.accountStatus = accountStatus;
	}
	
	// Client's last name, for javafx tables
	public String getLastName() {
		return client.getLastName();
	}
	
	// Client's last name, for javafx tables
	public String getMiddleName() {
		return client.getMiddleName();
	}
	
	// Client's first name, for java fx tables
	public String getFirstName() {
		return client.getFirstName();
	}
	
	// Client's phone no, for java fx tables
	public String getPhoneNumber() {
		return client.getContactPhone();
	}
	
	// Client's email address, for java fx tables
	public String getEmailAddress() {
		return client.getEmailAddress();
	}
}
