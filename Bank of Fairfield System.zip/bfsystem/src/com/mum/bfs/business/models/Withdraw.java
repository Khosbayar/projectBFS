package com.mum.bfs.business.models;

import com.mum.bfs.business.interfaces.Account;
import com.mum.bfs.business.interfaces.Transaction;
import com.mum.bfs.tools.Fee;

public class Withdraw extends Transaction {

	protected Withdraw(double tranAmount, Account fromAccountNo, Account toAccountNo, String transactionDescription,
			String location, User createdBy) {
		super(tranAmount, fromAccountNo, toAccountNo, transactionDescription, location, createdBy);
		super.setTranType(2);
		super.setStartBalance(fromAccountNo.getBalance());
		super.setEndBalance(super.getStartBalance() - tranAmount - Fee.withdraw.getAmount());
	}

	public boolean addTransaction() {
		if (this.getFromAccountNo().checkBalance(this.getTranAmount() + Fee.withdraw.getAmount())) {
			this.getToAccountNo()
					.setBalance(this.getToAccountNo().getBalance() + this.getTranAmount() + Fee.withdraw.getAmount());
			this.getFromAccountNo()
					.setBalance(this.getFromAccountNo().getBalance() - this.getTranAmount() - Fee.withdraw.getAmount());
			return true;
		}
		return false;
	}
}
