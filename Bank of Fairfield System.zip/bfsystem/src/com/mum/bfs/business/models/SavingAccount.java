package com.mum.bfs.business.models;

import com.mum.bfs.business.interfaces.Account;
import com.mum.bfs.tools.Fee;

public class SavingAccount extends Account {

	private int maturityOfSaving;

	SavingAccount(int accountNo, String accountName, double balance, boolean isBankAccount, int maturityOfSaving,
			Client client) {
		super(accountNo, accountName, balance, isBankAccount, client);
		this.maturityOfSaving = maturityOfSaving;
		switch (maturityOfSaving) {
		case 1:
			super.setInterestRate(0.03);
			break;
		case 2:
			super.setInterestRate(0.06);
			break;
		case 3:
			super.setInterestRate(0.09);
			break;
		case 6:
			super.setInterestRate(0.11);
			break;
		default:
			super.setInterestRate(0.00);
			break;
		}

		super.setMinimumBalance(10);
	}

	public double getSavingBookFee() {
		return Fee.savingBookFee.getAmount();
	}

	public int getMaturityOfSaving() {
		return maturityOfSaving;
	}

	public int getAccountType() {
		return 2;
	}

	@Override
	public double getMaintenanceFee() {
		// TODO Auto-generated method stub
		return 0;
	}

}
