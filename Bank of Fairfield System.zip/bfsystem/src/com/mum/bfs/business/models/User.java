package com.mum.bfs.business.models;

import java.time.*;
import com.mum.bfs.business.interfaces.*;

public class User extends Person{

	private int userID;
	private String userName;
	private String password;
	private int roleID;
	private LocalDate lastLoggedOn;
	private int status;
	
	User(int PersonID,String LastName,String MiddleName, String FirstName)
	{
		super(PersonID,LastName,MiddleName,FirstName);
	}
	
	void setUserID(int userID)
	{
		this.userID = userID;
	}
	
	public int getUserID()
	{
		return this.userID;
	}
	
	public String getUserName()
	{
		return this.userName;
	}
	
	public void setUserName(String userName)
	{
		this.userName = userName;
	}
	
	public String getPassword()
	{
		return this.password;
	}
	
	public void setPassword(String password)
	{
		this.password = password;
	}
	
	public int getRoleID()
	{
		return this.roleID;
	}
	
	public void setRoleID(int roleID)
	{
		this.roleID = roleID;
	}
	
	public LocalDate getLastLoggedOn()
	{
		return this.lastLoggedOn;
	}
	
	public void setLastLoggedOn(LocalDate lastLoggedOn)
	{
		this.lastLoggedOn = lastLoggedOn;
	}
	
	public int getStatus()
	{
		return this.status;
	}
	
	public void setStatus(int status)
	{
		this.status = status;
	}
	
	@Override
	public String displayName()
	{
		return String.format("%s, %s %s ( %s )",this.getLastName(),this.getFirstName(),this.getMiddleName(),this.userName);
	}
	
}
