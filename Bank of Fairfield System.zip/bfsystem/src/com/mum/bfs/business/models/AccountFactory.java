package com.mum.bfs.business.models;

import com.mum.bfs.business.interfaces.Account;

public final class AccountFactory {

	public static Account createCheckingAccount(int accountNo, String accountName, double balance,
			boolean isBankAccount, Client client) {
		Account a = new CheckingAccount(accountNo, accountName, balance, isBankAccount, client);
		return a;
	}

	public static Account createSavingAccount(int accountNo, String accountName, double balance, boolean isBankAccount,
			int maturityOfSaving, Client client) {
		Account a = new SavingAccount(accountNo, accountName, balance, isBankAccount, maturityOfSaving, client);
		return a;
	}
}
