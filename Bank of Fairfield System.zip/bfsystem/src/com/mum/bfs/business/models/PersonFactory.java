package com.mum.bfs.business.models;

import com.mum.bfs.business.interfaces.*;

public final class PersonFactory {
	
	public static Client createClient(int ID, String LastName, String MiddleName, String FirstName, int clientID)
	{
		if(LastName!=null && FirstName!=null)
		{
		Client client =  new Client(ID, LastName, MiddleName, FirstName);
		client.setClientID(clientID);
		return client;
		}
		else return null;
	}
	
	public static BankEmployee createBankEmployee(int ID,String LastName,String MiddleName, String FirstName, int employeeID)
	{
		if(LastName!=null && FirstName!=null) // validateEmployeeID(employeeID)
		{
		BankEmployee bankemployee =  new BankEmployee(ID,LastName,MiddleName, FirstName);
		bankemployee.setEmployeeID(employeeID); 
		return bankemployee;
		}
		else return null;
	}
	
	public static User createUser(int PersonID,String LastName,String MiddleName, String FirstName, int userID, String userName, String password)
	{
		if(LastName!=null && FirstName!=null && userName!=null && password!=null)
		{
	    User user =  new User(PersonID,LastName,MiddleName,FirstName);
	    user.setUserName(userName);
	    user.setUserID(userID);
	    //password = encryptPassword(password);
	    user.setPassword(password); 
	    
	    return user;
		}
		else return null;
	}
	
	public static boolean addAccountToClient(Account account, Client client)
	{
		if(client!=null && account!=null && account.getClient().getClientID()==client.getClientID())
		{
			client.addAccount(account);
			return true;
		}
		else return false;
	}
	
	private String encryptPassword(String password)
	{
		return "";
	}
	
	private boolean validateEmployeeID(String employeeID)
	{
		return true;
	}

}
