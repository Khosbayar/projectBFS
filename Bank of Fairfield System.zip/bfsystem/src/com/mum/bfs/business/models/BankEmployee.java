package com.mum.bfs.business.models;

import java.time.*;
import com.mum.bfs.business.interfaces.*;

class BankEmployee extends Person {

	private int employeeID;
	private String position;
	private double salary;
	
	BankEmployee(int PersonID,String LastName,String MiddleName, String FirstName)
	{
		super(PersonID,LastName,MiddleName,FirstName);
		
	}
	
	void setEmployeeID(int employeeID)
	{
		this.employeeID = employeeID;
	}
	
	public int getEmployeeID()
	{
		return this.employeeID;
	}
	
	
	
	public String getPosition()
	{
		return this.position;
	}
	
	public void setPosition(String position)
	{
		this.position = position;
	}
	
	public double getSalary()
	{
		return this.salary;
	}
	
	public void setSalary(double salary)
	{
		this.salary = salary;
	}
	
	@Override
	public String displayName()
	{
		String addr = this.getSex().equals("Female")?"Ms.":"Mr.";
		return String.format("%s %s %s %s (%s)",addr,this.getFirstName(),this.getMiddleName(),this.getLastName(),this.getPosition());
	}
}
