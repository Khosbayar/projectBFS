package com.mum.bfs.business.models;

import com.mum.bfs.business.interfaces.Account;
import com.mum.bfs.tools.Fee;

public class CheckingAccount extends Account {

	protected CheckingAccount(int accountNo, String accountName, double balance, boolean isBankAccount, Client client) {
		super(accountNo, accountName, balance, isBankAccount, client);
		super.setMinimumBalance(5);
		super.setInterestRate(0.01);
	}

	public double getMaintenanceFee() {
		return Fee.maintenanceFee.getAmount();
	}

	public int getAccountType() {
		return 1;
	}

	@Override
	public double getSavingBookFee() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getMaturityOfSaving() {
		// TODO Auto-generated method stub
		return 0;
	}
}
