package com.mum.bfs.business.models;

import com.mum.bfs.business.interfaces.Account;
import com.mum.bfs.business.interfaces.Transaction;
import com.mum.bfs.business.services.AccountService;
import com.mum.bfs.business.services.TransactionService;

public final class TransactionFactory {

	static AccountService as = new AccountService();
	static TransactionService ts = new TransactionService();

	public static Transaction createDepositTransaction(double tranAmount, Account toAccountNo,
			String transactionDescription, String location, User createdBy) {
		Account fromAccountNo = as.getRecord(4100001);
		Transaction tran = new Deposit(tranAmount, fromAccountNo, toAccountNo, transactionDescription, location,
				createdBy);
		return tran;
	}

	public static Transaction createWithdrawTransaction(double tranAmount, Account fromAccountNo,
			String transactionDescription, String location, User createdBy) {
		Account toAccountNo = as.getRecord(4100002);
		Transaction tran = new Withdraw(tranAmount, fromAccountNo, toAccountNo, transactionDescription, location,
				createdBy);
		return tran;
	}

	public static Transaction createTransferFund(double tranAmount, Account fromAccountNo, Account toAccountNo,
			String transactionDescription, String location, User createdBy) {
		Transaction tran = new FundTransfer(tranAmount, fromAccountNo, toAccountNo, transactionDescription, location,
				createdBy);
		return tran;
	}

	public static boolean doUpdate(Transaction tran) {
		if(tran.addTransaction()) {
			ts.addRecord(tran);
			Account toAcc = tran.getToAccountNo();
			as.updateRecord(toAcc, toAcc.getAccountNo());
			Account fromAcc = tran.getFromAccountNo();
			as.updateRecord(fromAcc, fromAcc.getAccountNo());
			return true;
		}
		else {
			return false;
		}
		
	}
}
