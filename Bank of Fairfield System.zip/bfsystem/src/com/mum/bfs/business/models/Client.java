package com.mum.bfs.business.models;

import java.time.*;
import java.util.*;
import com.mum.bfs.business.interfaces.*;

public class Client extends Person {

	private int clientID;
	private String motherMaidenName;
	private String signature;
	private String photo;
	private List<Account> accounts;

	Client(int PersonID, String LastName, String MiddleName, String FirstName) {
		super(PersonID, LastName, MiddleName, FirstName);
		
	}

	void setClientID(int clientID)
	{
		this.clientID = clientID;
	}
	
	public int getClientID() {
		return this.clientID;
	}

	public String getMotherMaidenName() {
		return this.motherMaidenName;
	}

	public void setMotherMaidenName(String motherMaidenName) {
		this.motherMaidenName = motherMaidenName;
	}

	public String getSignature() {
		return this.signature;
	}

	public void setSignature(String signature) {
		this.signature = signature;
	}

	public String getPhoto() {
		return this.photo;
	}

	public void setPhoto(String photo) {
		this.photo = photo;
	}
	
	public void setAccounts(List<Account> accounts)
	{
		this.accounts = accounts;
	}
	
	public List<Account> getAccounts()
	{
		return this.accounts;
	}
	
	void addAccount(Account account)
	{
		this.accounts.add(account);
	}
	
	@Override
	public String displayName()
	{
		String addr = this.getSex().equals("Female")?"Ms.":"Mr.";
		return String.format("%s %s %s %s",addr,this.getFirstName(),this.getMiddleName(),this.getLastName());
	}

}
