package com.mum.bfs.business.models;

import com.mum.bfs.business.interfaces.Account;
import com.mum.bfs.business.interfaces.Transaction;
import com.mum.bfs.tools.Fee;

public class FundTransfer extends Transaction {

	protected FundTransfer(double tranAmount, Account fromAccountNo, Account toAccountNo, String transactionDescription,
			String location, User createdBy) {
		super(tranAmount, fromAccountNo, toAccountNo, transactionDescription, location, createdBy);
		super.setTranType(3);
		super.setStartBalance(fromAccountNo.getBalance());
		super.setEndBalance(super.getStartBalance() - tranAmount - Fee.onlineTransaction.getAmount()
				- Fee.onlineWithdraw.getAmount());
	}

	public boolean addTransaction() {
		if (this.getFromAccountNo().checkBalance(
				this.getTranAmount() + Fee.onlineTransaction.getAmount() + Fee.onlineWithdraw.getAmount())) {
			this.getToAccountNo().setBalance(this.getToAccountNo().getBalance() + this.getTranAmount()
					+ Fee.onlineTransaction.getAmount() + Fee.onlineWithdraw.getAmount());
			this.getFromAccountNo().setBalance(this.getFromAccountNo().getBalance() - this.getTranAmount()
					- Fee.onlineTransaction.getAmount() - Fee.onlineWithdraw.getAmount());
			return true;
		}
		return false;
	}

}
