package com.mum.bfs.business.models;

import com.mum.bfs.business.interfaces.Account;
import com.mum.bfs.business.interfaces.Transaction;

public class Deposit extends Transaction {

	protected Deposit(double tranAmount, Account fromAccountNo, Account toAccountNo, String transactionDescription,
			String location, User createdBy) {
		super(tranAmount, fromAccountNo, toAccountNo, transactionDescription, location, createdBy);
		super.setTranType(1);
		super.setStartBalance(toAccountNo.getBalance());
		super.setEndBalance(super.getStartBalance() + tranAmount);
	}

	public boolean addTransaction() {
		this.getToAccountNo().setBalance(this.getToAccountNo().getBalance() + this.getTranAmount());
		this.getFromAccountNo().setBalance(this.getFromAccountNo().getBalance() - this.getTranAmount());
		return true;
	}
}
