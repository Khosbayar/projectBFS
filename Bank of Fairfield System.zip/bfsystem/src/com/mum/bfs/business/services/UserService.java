package com.mum.bfs.business.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.*;
import java.time.*;

import com.mum.bfs.business.interfaces.*;
import com.mum.bfs.business.models.*;
import com.mum.bfs.dataaccess.*;
import com.mum.bfs.tools.*;

public class UserService implements IService<User> {

	private DBProvider dbProvider;

	public UserService() {
		this.dbProvider = new DBProvider();
	}

	@Override
	public int addRecord(User object)
	{
		
	
			int newID = this.getNextID();
			String sql = "insert into user (ID, PersonID, UserName, Password, RoleID, LastLoggedOn, Status, CreatedDate, CreatedBy, LastUpdated, UpdatedBy) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
			
			HashMap<Integer,String> params = new HashMap<Integer,String>();
			params.put(1, String.format("%d",newID));
			params.put(2, String.format("%d",object.getID()));
			params.put(3, object.getUserName());
			params.put(4, object.getPassword());
			params.put(5, String.format("%d",object.getRoleID()));
			params.put(6, LocalDate.now().toString());
			params.put(7, String.format("%d",object.getStatus()));
			params.put(8, LocalDate.now().toString());
			params.put(9, "2");
			params.put(10, LocalDate.now().toString());
			params.put(11, "2");
			
			int result = dbProvider.addUpdateRow(sql, params);
			
			if(result!=0) result = newID;
		
			return result;
	}

	@Override
	public User getRecord(int ID) {
		User user;

		String sql = "SELECT * from Person inner join User on Person.ID = User.PersonID where User.ID=?";

		HashMap<Integer, String> params = new HashMap<Integer, String>();
		params.put(1, String.format("%s", ID));

		HashMap<String, String> rs = dbProvider.getRow(sql, params);

		if (rs != null && !rs.isEmpty()) {
			try {
				int pid = Integer.parseInt(rs.get("PersonID"));
				String LastName = rs.get("LastName");
				String MiddleName = rs.get("MiddleName");
				String FirstName = rs.get("FirstName");
				String userName = rs.get("UserName");
				String password = rs.get("Password");
				LocalDate BirthDate = LocalDate.parse((CharSequence) rs.get("BirthDate"));
				String ContactPhone = rs.get("ContactPhone");
				String EmailAddress = rs.get("EmailAddress");
				String ContactPhone2 = rs.get("ContactPhone2");
				String No = rs.get("No");
				String Street = rs.get("Street");
				String City = rs.get("City");
				String State = rs.get("State");
				String Zip = rs.get("Zip");
				String Sex = rs.get("Sex");
				String SSN = rs.get("SSN");
				int roleID = Integer.parseInt(rs.get("RoleID"));
				int Status = Integer.parseInt(rs.get("Status"));
				String lastLoggedOnStr = rs.get("LastLoggedOn") == null || rs.get("LastLoggedOn") == "" ? ""
						: rs.get("LastLoggedOn");
				LocalDate lastLoggedOn = !lastLoggedOnStr.isEmpty() ? LocalDate.parse((CharSequence) lastLoggedOnStr)
						: null;
				user = PersonFactory.createUser(pid, LastName, MiddleName, FirstName, ID, userName, password);
				user.setAddress(No, Street, City, State, Zip);
				user.setBirthDate(BirthDate);
				user.setContactPhone(ContactPhone);
				user.setContactPhone2(ContactPhone2);
				user.setSex(Sex);
				user.setSSN(SSN);
				user.setEmailAddress(EmailAddress);
				user.setRoleID(roleID);
				user.setLastLoggedOn(lastLoggedOn);
				user.setStatus(Status);

				return user;
			} catch (Exception ex) {
				Printer.printToConsole(ex.getMessage());
			}

		}

		return null;

	}

	public User getRecordByPerson(int personID) {
		User user;

		String sql = "SELECT User.ID as userID,* from Person inner join User on Person.ID = User.PersonID where PersonID=?";

		HashMap<Integer, String> params = new HashMap<Integer, String>();
		params.put(1, String.format("%s", personID));

		HashMap<String, String> rs = dbProvider.getRow(sql, params);

		if (rs != null && !rs.isEmpty()) {
			try {
				int pid = Integer.parseInt(rs.get("PersonID"));
				String LastName = rs.get("LastName");
				String MiddleName = rs.get("MiddleName");
				String FirstName = rs.get("FirstName");
				String userName = rs.get("UserName");
				String password = rs.get("Password");
				int Status = Integer.parseInt(rs.get("Status"));
				LocalDate BirthDate = LocalDate.parse((CharSequence) rs.get("BirthDate"));
				String ContactPhone = rs.get("ContactPhone");
				String EmailAddress = rs.get("EmailAddress");
				String ContactPhone2 = rs.get("ContactPhone2");
				String No = rs.get("No");
				String Street = rs.get("Street");
				String City = rs.get("City");
				String State = rs.get("State");
				String Zip = rs.get("Zip");
				String Sex = rs.get("Sex");
				String SSN = rs.get("SSN");
				int userID = Integer.parseInt(rs.get("userID"));
				int roleID = Integer.parseInt(rs.get("RoleID"));
				String lastLoggedOnStr = rs.get("LastLoggedOn") == null || rs.get("LastLoggedOn") == "" ? ""
						: rs.get("LastLoggedOn");
				LocalDate lastLoggedOn = !lastLoggedOnStr.isEmpty() ? LocalDate.parse((CharSequence) lastLoggedOnStr)
						: null;
				user = PersonFactory.createUser(pid, LastName, MiddleName, FirstName, userID, userName, password);
				user.setAddress(No, Street, City, State, Zip);
				user.setBirthDate(BirthDate);
				user.setContactPhone(ContactPhone);
				user.setContactPhone2(ContactPhone2);
				user.setSex(Sex);
				user.setSSN(SSN);
				user.setEmailAddress(EmailAddress);
				user.setRoleID(roleID);
				user.setLastLoggedOn(lastLoggedOn);
				user.setStatus(Status);

				return user;
			} catch (Exception ex) {
				Printer.printToConsole(ex.getMessage());
			}

		}

		return null;

	}

	@Override
	public int updateRecord(User object, int ID) {

		String sql = "UPDATE User SET UserName=?, Password=?,RoleID=?,LastLoggedOn=?,Status=?,LastUpdated=?,UpdatedBy=? where ID=?";

		HashMap<Integer, String> params = new HashMap<Integer, String>();

		params.put(1, object.getUserName());
		params.put(2, object.getPassword());
		params.put(3, String.format("%d", object.getRoleID()));
		String lastLoggedOnStr = object.getLastLoggedOn() == null ? "" : object.getLastLoggedOn().toString();
		params.put(4, lastLoggedOnStr);
		params.put(5, String.format("%d", object.getStatus()));
		params.put(6, LocalDate.now().toString());
		params.put(7, String.format("%d", 2)); // temporary for updatedby need to use sessionobject!!
		params.put(8, String.format("%d", ID));

		int result = dbProvider.addUpdateRow(sql, params);

		return result;

	}

	@Override
	public void deleteRecord(int ID) {

	}

	@Override
	public int getNextID() {

		String SQL = "SELECT max(ID)+1 as nextID from user";
		int result = this.dbProvider.getNextID(SQL);

		return result;

	}

	public User getSignInUser(String username, String password) {
		User user;

		String sql = "SELECT *,User.ID as UserID from Person inner join User on Person.ID = User.PersonID where User.UserName=? AND User.Password=?";

		HashMap<Integer, String> params = new HashMap<Integer, String>();
		params.put(1, String.format("%s", username));
		params.put(2, String.format("%s", password));

		HashMap<String, String> rs = dbProvider.getRow(sql, params);

		if (rs != null && !rs.isEmpty()) {
			try {
				int pid = Integer.parseInt(rs.get("ID"));
				int ID = Integer.parseInt(rs.get("UserID"));
				String LastName = rs.get("LastName");
				String MiddleName = rs.get("MiddleName");
				String FirstName = rs.get("FirstName");
				String userName = rs.get("UserName");
				LocalDate BirthDate = LocalDate.parse((CharSequence) rs.get("BirthDate"));
				String ContactPhone = rs.get("ContactPhone");
				String EmailAddress = rs.get("EmailAddress");
				String ContactPhone2 = rs.get("ContactPhone2");
				String No = rs.get("No");
				String Street = rs.get("Street");
				String City = rs.get("City");
				String State = rs.get("State");
				String Zip = rs.get("Zip");
				String Sex = rs.get("Sex");
				String SSN = rs.get("SSN");
				int roleID = Integer.parseInt(rs.get("RoleID"));
				int Status = Integer.parseInt(rs.get("Status"));
				String lastLoggedOnStr = rs.get("LastLoggedOn") == null || rs.get("LastLoggedOn") == "" ? ""
						: rs.get("LastLoggedOn");
				LocalDate lastLoggedOn = !lastLoggedOnStr.isEmpty() ? LocalDate.parse((CharSequence) lastLoggedOnStr)
						: null;
				user = PersonFactory.createUser(pid, LastName, MiddleName, FirstName, ID, userName, password);
				user.setAddress(No, Street, City, State, Zip);
				user.setBirthDate(BirthDate);
				user.setContactPhone(ContactPhone);
				user.setContactPhone2(ContactPhone2);
				user.setSex(Sex);
				user.setSSN(SSN);
				user.setEmailAddress(EmailAddress);
				user.setRoleID(roleID);
				user.setLastLoggedOn(lastLoggedOn);
				user.setStatus(Status);

				return user;

			} catch (Exception ex) {
				Printer.printToConsole(ex.getMessage());
			}

		}

		return null;

	}

	public static void main(String[] args) {
		UserService userservice = new UserService();

		// get User by ID
		// User user = userservice.getRecord(2);

		// adding record into User
		/*
		 * int ID = 3; // person id String LastName = "not matter"; String MiddleName =
		 * "not matter"; String FirstName = "not matter"; String userName = "Bank";
		 * String password = "password2"; int userID = 0; // does not matter for now int
		 * roleID = 2; int status = 1; User user = new
		 * User(ID,LastName,MiddleName,FirstName,userID, userName, password);
		 * user.setRoleID(roleID); user.setStatus(status); userservice.addRecord(user);
		 */

		// updating a user record
		/*
		 * User user = userservice.getRecord(3); user.setUserName("Bank new username");
		 * user.setPassword("new password"); user.setRoleID(3);
		 * user.setLastLoggedOn(LocalDate.now().minusDays(1)); user.setStatus(2);
		 * 
		 * userservice.updateRecord(user, 3);
		 */

		// SignIn check
		/*
		 * User user = userservice.getSignInUser("Bank new username", "new password11");
		 * 
		 * int ko = 0;
		 */

		// check if there is User if not, create, if there is, update

		/*
		 * User user = userservice.getRecordByPerson(65738);
		 * 
		 * 
		 * if(user==null) { user = PersonFactory.createUser(65738, "asfa", "sfasdf",
		 * "asfasd", 0, "new username", "new password"); int newid =
		 * userservice.addRecord(user); //if newid <=0 no creation, otherwise returns
		 * new ID } else { user.setUserName("username 2");
		 * user.setPassword("password 2"); int res = userservice.updateRecord(user,
		 * user.getUserID()); // <=0 means failure otherwise success }
		 * 
		 * System.out.print(user.getUserName());
		 */
	}

}
