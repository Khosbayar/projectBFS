package com.mum.bfs.business.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.*;
import java.time.*;

import com.mum.bfs.business.interfaces.*;
import com.mum.bfs.business.models.*;
import com.mum.bfs.dataaccess.*;
import com.mum.bfs.tools.*;

public class ClientService implements IService<Client> {

private DBProvider dbProvider;
	
	public ClientService()
	{
		this.dbProvider = new DBProvider();
	}


	@Override
	public int addRecord(Client object)
	{
		int newID = this.getNextID();
		String sql = "insert into client (ID, PersonID, MotherMaidenName, Signature, Photo, CreatedDate, CreatedBy, LastUpdated, UpdatedBy) values (?, ?, ?, ?, ?, ?, ?, ?, ?)";
		
		HashMap<Integer,String> params = new HashMap<Integer,String>();
		params.put(1, String.format("%d",newID));
		params.put(2, String.format("%d",object.getID()));
		params.put(3, object.getMotherMaidenName());
		params.put(4, object.getSignature());
		params.put(5, object.getPhoto());
		params.put(6, LocalDate.now().toString());
		params.put(7, "2");
		params.put(8, LocalDate.now().toString());
		params.put(9, "2");
	
        int result = dbProvider.addUpdateRow(sql, params);
		
		if(result!=0) result = newID;
		
		return result;
		
		
	}
	
	
	
	public Client getRecordByPerson(int personID)
	{
        Client client;
		
		String sql = "SELECT *,Client.ID as ClientID from Person inner join Client on Person.ID = Client.PersonID where Person.ID=?";
		
		HashMap<Integer,String> params = new HashMap<Integer,String>();
		params.put(1, String.format("%s", personID));
		
		HashMap<String,String> rs = dbProvider.getRow(sql, params);
		
		if(rs!=null && !rs.isEmpty())
		{
			try
			{
			int clientID = Integer.parseInt(rs.get("ClientID"));
			String LastName = rs.get("LastName");
			String MiddleName = rs.get("MiddleName");
			String FirstName = rs.get("FirstName");
			LocalDate BirthDate  = LocalDate.parse((CharSequence)rs.get("BirthDate"));
			String ContactPhone = rs.get("ContactPhone");
			String EmailAddress = rs.get("EmailAddress");
			String ContactPhone2  = rs.get("ContactPhone2");
			String 	No  = rs.get("No");
			String 	Street  = rs.get("Street");
			String 	City  = rs.get("City");
			String 	State  = rs.get("State");
			String 	Zip  = rs.get("Zip");
			String 	Sex  = rs.get("Sex");
			String 	SSN  = rs.get("SSN");
			String motherMaidenName =  rs.get("MotherMaidenName");
			String signature =  rs.get("Signature");
			String photo =  rs.get("Photo");
			client = PersonFactory.createClient(personID, LastName, MiddleName, FirstName,clientID);
			client.setAddress(No, Street, City, State, Zip);
			client.setBirthDate(BirthDate);
			client.setContactPhone(ContactPhone);
			client.setContactPhone2(ContactPhone2);
			client.setSex(Sex);
			client.setSSN(SSN);
			client.setEmailAddress(EmailAddress);
			client.setMotherMaidenName(motherMaidenName);
			client.setSignature(signature);
			client.setPhoto(photo);
		    
		    return client;
		    
			}
		 catch(Exception ex) {
			Printer.printToConsole(ex.getMessage());
		}
		
		}
		
		return null;
	
		
	
	
	
	}
	
	@Override
	public Client getRecord(int clientID)
	{
        Client client;
		
		String sql = "SELECT * from Person inner join Client on Person.ID = Client.PersonID where Client.ID=?";
		
		HashMap<Integer,String> params = new HashMap<Integer,String>();
		params.put(1, String.format("%s", clientID));
		
		HashMap<String,String> rs = dbProvider.getRow(sql, params);
		
		if(rs!=null && !rs.isEmpty())
		{
			try
			{
			int pid = Integer.parseInt(rs.get("PersonID"));
			String LastName = rs.get("LastName");
			String MiddleName = rs.get("MiddleName");
			String FirstName = rs.get("FirstName");
			LocalDate BirthDate  = LocalDate.parse((CharSequence)rs.get("BirthDate"));
			String ContactPhone = rs.get("ContactPhone");
			String EmailAddress = rs.get("EmailAddress");
			String ContactPhone2  = rs.get("ContactPhone2");
			String 	No  = rs.get("No");
			String 	Street  = rs.get("Street");
			String 	City  = rs.get("City");
			String 	State  = rs.get("State");
			String 	Zip  = rs.get("Zip");
			String 	Sex  = rs.get("Sex");
			String 	SSN  = rs.get("SSN");
			String motherMaidenName =  rs.get("MotherMaidenName");
			String signature =  rs.get("Signature");
			String photo =  rs.get("Photo");
			client = PersonFactory.createClient(pid, LastName, MiddleName, FirstName,clientID);
			client.setAddress(No, Street, City, State, Zip);
			client.setBirthDate(BirthDate);
			client.setContactPhone(ContactPhone);
			client.setContactPhone2(ContactPhone2);
			client.setSex(Sex);
			client.setSSN(SSN);
			client.setEmailAddress(EmailAddress);
			client.setMotherMaidenName(motherMaidenName);
			client.setSignature(signature);
			client.setPhoto(photo);
		    
		    return client;
		    
			}
		 catch(Exception ex) {
			Printer.printToConsole(ex.getMessage());
		}
		
		}
		
		return null;
	
		
	
	
	
	}
	
	@Override
	public int updateRecord(Client object, int ID)
	{
		
		String sql = "UPDATE Client SET MotherMaidenName=?, Signature=?,Photo=?,LastUpdated=?,UpdatedBy=? where ID=?";
		
		
		HashMap<Integer,String> params = new HashMap<Integer,String>();
		
		
		params.put(1, object.getMotherMaidenName());
		params.put(2, object.getSignature());
		params.put(3, object.getPhoto());
		params.put(4, LocalDate.now().toString());
		params.put(5, "2");
		params.put(6, String.format("%d",ID));
		
		int result = dbProvider.addUpdateRow(sql, params);
		
		return result;
			
	
	}
	
	@Override
	public void deleteRecord(int ID)
	{
		
	}
	
	@Override
	public int getNextID()
	{
			
			String SQL = "SELECT max(ID)+1 as nextID from client";
			int result = this.dbProvider.getNextID(SQL);
			
			return result;
		
	}
	
	
	public List<Client> getAllClients()
	{
		List<Client> clients = new ArrayList<Client>();
		
		
		String sql = "SELECT Client.ID as ClientID,* from Client inner join Person on Client.PersonID = Person.ID";
		
		HashMap<Integer,String> params = new HashMap<Integer,String>();
		
		List<HashMap<String,String>> results = dbProvider.getMultipleRows(sql, params);
		
		for(HashMap<String, String> rs: results)
		{
		Client client = null;
		if(rs!=null && !rs.isEmpty())
		{
			try
			{
			int pid = Integer.parseInt(rs.get("PersonID"));
			String LastName = rs.get("LastName");
			String MiddleName = rs.get("MiddleName");
			String FirstName = rs.get("FirstName");
			LocalDate BirthDate  = LocalDate.parse((CharSequence)rs.get("BirthDate"));
			String ContactPhone = rs.get("ContactPhone");
			String EmailAddress = rs.get("EmailAddress");
			String ContactPhone2  = rs.get("ContactPhone2");
			String 	No  = rs.get("No");
			String 	Street  = rs.get("Street");
			String 	City  = rs.get("City");
			String 	State  = rs.get("State");
			String 	Zip  = rs.get("Zip");
			String 	Sex  = rs.get("Sex");
			String 	SSN  = rs.get("SSN");
			String motherMaidenName =  rs.get("MotherMaidenName");
			String signature =  rs.get("Signature");
			String photo =  rs.get("Photo");
			int clientID = Integer.parseInt(rs.get("ClientID"));
			client = PersonFactory.createClient(pid, LastName, MiddleName, FirstName,clientID);
			client.setAddress(No, Street, City, State, Zip);
			client.setBirthDate(BirthDate);
			client.setContactPhone(ContactPhone);
			client.setContactPhone2(ContactPhone2);
			client.setSex(Sex);
			client.setSSN(SSN);
			client.setEmailAddress(EmailAddress);
			client.setMotherMaidenName(motherMaidenName);
			client.setSignature(signature);
			client.setPhoto(photo);
		    
		    
			}
		 catch(Exception ex) {
			Printer.printToConsole(ex.getMessage()); }
		
		}
		
		if(client!=null)
			clients.add(client);
		
	
		
	
		}
	
		
		return clients;
	}
	
	public List<Client> searchClients(String lastname, String firstname, String middlename, String phone, String ssn, int accountid)
	{
		
        List<Client> clients = new ArrayList<Client>();
		
		
		String sql = "SELECT Client.ID as ClientID,* from Person inner join Client on Person.ID = Client.PersonID " 
				+ " where UPPER(LastName) = UPPER(?) OR UPPER(FirstName) = UPPER(?) OR UPPER(MiddleName) = UPPER(?) OR UPPER(ContactPhone) = UPPER(?) OR UPPER(SSN) = UPPER(?) OR Client.ID in (Select ClientID from Account where Account.ID = ?)";

		HashMap<Integer,String> params = new HashMap<Integer,String>();
		params.put(1, lastname);
		params.put(2, firstname);
		params.put(3, middlename);
		params.put(4, phone);
		params.put(5, ssn);
		params.put(6, Integer.toString(accountid));
		
		List<HashMap<String,String>> results = dbProvider.getMultipleRows(sql, params);
		
		for(HashMap<String, String> rs: results)
		{
		Client client = null;
		if(rs!=null && !rs.isEmpty())
		{
			try
			{
			int pid = Integer.parseInt(rs.get("PersonID"));
			String LastName = rs.get("LastName");
			String MiddleName = rs.get("MiddleName");
			String FirstName = rs.get("FirstName");
			LocalDate BirthDate  = LocalDate.parse((CharSequence)rs.get("BirthDate"));
			String ContactPhone = rs.get("ContactPhone");
			String EmailAddress = rs.get("EmailAddress");
			String ContactPhone2  = rs.get("ContactPhone2");
			String 	No  = rs.get("No");
			String 	Street  = rs.get("Street");
			String 	City  = rs.get("City");
			String 	State  = rs.get("State");
			String 	Zip  = rs.get("Zip");
			String 	Sex  = rs.get("Sex");
			String 	SSN  = rs.get("SSN");
			String motherMaidenName =  rs.get("MotherMaidenName");
			String signature =  rs.get("Signature");
			String photo =  rs.get("Photo");
			int clientID = Integer.parseInt(rs.get("ClientID"));
			client = PersonFactory.createClient(pid, LastName, MiddleName, FirstName,clientID);
			client.setAddress(No, Street, City, State, Zip);
			client.setBirthDate(BirthDate);
			client.setContactPhone(ContactPhone);
			client.setContactPhone2(ContactPhone2);
			client.setSex(Sex);
			client.setSSN(SSN);
			client.setEmailAddress(EmailAddress);
			client.setMotherMaidenName(motherMaidenName);
			client.setSignature(signature);
			client.setPhoto(photo);
		    
		    
			}
		 catch(Exception ex) {
			Printer.printToConsole(ex.getMessage()); }
		
		}
		
		if(client!=null)
			clients.add(client);
		
	
		
	
		}
	
		
		return clients;
	
		
		
	}

	 public static void main(String[] args) {
			ClientService clientService = new ClientService();
			
			//get Client by Person ID
			//Client client = clientService.getRecordByPerson(65741);
			 
			//get Client by ID
			/*Client client = clientService.getRecord(1);
			
		*/
	
			// adding record into Client without ID return
						/*int ID = 2; // person id
						String LastName = "not matter";
						String MiddleName = "not matter";
						String FirstName = "not matter";
						String motherMaidenName = "Hillary Trump";
						String signature = "C:\\hillarysignature.jpg";
						String photo = "C:\\hillaryphoto.jpg";
						
						int clientID = 0; // does not matter for now
						Client client = PersonFactory.createClient(ID, LastName, MiddleName, FirstName, clientID);
						client.setPhoto(photo);
						client.setSignature(signature);
						client.setMotherMaidenName(motherMaidenName);
						
						int newID = clientService.addRecord(client);
						int ki = 0;*/
			
			
			
			// updating a client record
						/*Client client = clientService.getRecord(1);
						client.setMotherMaidenName("Georgiana Bush");
						client.setSignature("C:\\mysig1.jpg");
						client.setPhoto("C:\\myphoto1.jpg");
						
						clientService.updateRecord(client,1); */
			
			//get list of all clients
			/*List<Client> clients = clientService.getAllClients();
			int ki = 0;*/
			
			//search for clients
			
			/*List<Client> foundClients = clientService.searchClients("paxson","John","Fairfield","12345","124125",1 );
		    
			System.out.print(foundClients.size());*/
		
			
			
		}
	 

}
