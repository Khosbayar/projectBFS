package com.mum.bfs.business.services;

import java.time.LocalDate;
import java.util.HashMap;

import com.mum.bfs.business.interfaces.*;
import com.mum.bfs.business.models.*;
import com.mum.bfs.dataaccess.DBProvider;

public class PersonService implements IService<Person> {
	
	private DBProvider dbProvider;
	
	public PersonService()
	{
		this.dbProvider = new DBProvider();
		
	}
	
	
	@Override
	public int addRecord(Person object)
	{
        int result = 0;
		
		int newID = this.getNextID();
		String sql = "insert into Person (ID, LastName, MiddleName,FirstName,Birthdate,ContactPhone,EmailAddress,ContactPhone2,No,Street,City,State,Zip,LastUpdated,UpdatedBy,Sex,SSN) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		
		HashMap<Integer,String> params = new HashMap<Integer,String>();
		params.put(1, String.format("%d",newID));
		params.put(2, object.getLastName());
		params.put(3, object.getMiddleName());
		params.put(4, object.getFirstName());
		params.put(5, object.getBirthDate().toString());
		params.put(6, object.getContactPhone());
		params.put(7, object.getEmailAddress());
		params.put(8, object.getContactPhone2());
		params.put(9, object.getNo());
		params.put(10, object.getStreet());
		params.put(11, object.getCity());
		params.put(12, object.getState());
		params.put(13, object.getZip());
		params.put(14, LocalDate.now().toString());
		params.put(15, "2");
		params.put(16, object.getSex());
		params.put(17, object.getSSN());
		
		result = dbProvider.addUpdateRow(sql, params);
		
        if(result!=0) result = newID;
        
		return result;
	
	}
	
	@Override
	public Person getRecord(int ID)
	{
		return null;
	}
	
	@Override
	public int updateRecord(Person object, int ID)
	{
        String sql = "UPDATE Person SET LastName=?, MiddleName=?,FirstName=?,BirthDate=?,ContactPhone=?, "
		+ "  EmailAddress=?,  ContactPhone2=?,  No=?,  Street=?,  City=?,  State=?,  Zip=?,  LastUpdated=?,"
		+ "  UpdatedBy=?,  Sex=?,  SSN=?"
		+ " where ID=?";
		
		
		HashMap<Integer,String> params = new HashMap<Integer,String>();
		
		
		params.put(1, object.getLastName());
		params.put(2, object.getMiddleName());
		params.put(3, object.getFirstName());
		params.put(4, object.getBirthDate().toString());
		params.put(5, object.getContactPhone());
		params.put(6, object.getEmailAddress());
		params.put(7, object.getContactPhone2());
		params.put(8, object.getNo());
		params.put(9, object.getStreet());
		params.put(10, object.getCity());
		params.put(11, object.getState());
		params.put(12, object.getZip());
		params.put(13, LocalDate.now().toString());
		params.put(14, "2");
		params.put(15, object.getSex());
		params.put(16, object.getSSN());
		params.put(17, String.format("%d",ID));
		
		int result = dbProvider.addUpdateRow(sql, params);
		
		return result;
	}
	
	@Override
	public void deleteRecord(int ID)
	{
		
	}
	
	@Override
	public int getNextID()
	{
		String SQL = "SELECT max(ID)+1 as nextID from person";
		int result = this.dbProvider.getNextID(SQL);
		
		return result;
	}
	
	public static void main(String[] args)
	{
		/*
		// testing PersonService add person
		// when we add a client, we also add the person automatically
		
		PersonService personService = new PersonService();
		ClientService clientService = new ClientService();
		
		int ID = 20000; // person id not matter
		String LastName = "Paxson";
		String MiddleName = "Billy";
		String FirstName = "Rica";
		LocalDate BirthDate = LocalDate.now();
		String Sex = "Female";
		String SSN = "New SSN123";
		String No = "99 N";
		String Street = "5th Street";
		String City = "New York";
		String State = "NY";
		String Zip = "New Zip";
		String motherMaidenName = "new mother mainden name";
		String signature = "C:\\mymothersignature.jpg";
		String photo = "C:\\mymotherphoto.jpg";
			
		int clientID = 80000; // does not matter for now
		Client client = PersonFactory.createClient(ID, LastName, MiddleName, FirstName, clientID);
		client.setLastName(LastName);
		client.setMiddleName(MiddleName);
		client.setFirstName(FirstName);
		client.setBirthDate(BirthDate);
		client.setSex(Sex);
		client.setSSN(SSN);
		client.setNo(No);
		client.setStreet(Street);
		client.setCity(City);
		client.setState(State);
		client.setZip(Zip);
		client.setPhoto(photo);
		client.setSignature(signature);
		client.setMotherMaidenName(motherMaidenName);
		
		int newPersonID = personService.addRecord(client);
		if(newPersonID!=0) // if not zero, person was created so proceed to creating client
		{
		client.setID(newPersonID);
		int newClientID = clientService.addRecord(client);
		// if newClientID==0 it client was not successfully created
		}	
		
		*/
		
		//update person
		/*PersonService personservice = new PersonService();
		
		ClientService clientservice = new ClientService();
		
		Client client = clientservice.getRecord(65739);
		client.setLastName("Doe 3");
		client.setMiddleName("updated kirk3");
		client.setCity("Des Moines");
		
		personservice.updateRecord(client, client.getID());
		
		System.out.println(client.getCity());*/
		
	}

}
