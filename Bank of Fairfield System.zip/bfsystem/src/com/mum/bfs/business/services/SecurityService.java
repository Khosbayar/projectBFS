package com.mum.bfs.business.services;

import com.mum.bfs.business.models.User;
import com.mum.bfs.tools.*;

public class SecurityService {
	private UserService userService;

	public SecurityService() {
		userService = new UserService();
	}

	public Result<User> Authenticate(String userName, String password) {

		User user = userService.getSignInUser(userName, password);

		if (user == null)
			return new Result<User>(-10, "Username or password is wrong");
		return new Result<User>(user);
	}
}
