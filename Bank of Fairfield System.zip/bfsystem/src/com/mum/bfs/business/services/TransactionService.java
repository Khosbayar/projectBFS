package com.mum.bfs.business.services;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.mum.bfs.business.interfaces.Account;
import com.mum.bfs.business.interfaces.IService;
import com.mum.bfs.business.interfaces.Transaction;
import com.mum.bfs.business.models.TransactionFactory;
import com.mum.bfs.business.models.User;
import com.mum.bfs.dataaccess.DBProvider;
import com.mum.bfs.tools.Result;
import com.sun.xml.internal.ws.util.ReadAllStream;

public class TransactionService implements IService<Transaction> {

	DBProvider dbProvider;
	static TransactionService ts = new TransactionService();
	static AccountService as = new AccountService();
	static UserService us = new UserService();

	public TransactionService() {
		dbProvider = new DBProvider();
	}

	@Override
	public int addRecord(Transaction tran) {
		// TODO Auto-generated method stub
		String SQL = "INSERT INTO 'Transaction' VALUES(?,?,?,?,?,?,?,?,?,?,?)";
		HashMap<Integer, String> params = new HashMap<Integer, String>();
		int newID = getNextID();
		params.put(1, String.format("%d", newID));
		params.put(2, String.format("%d", tran.getFromAccountNo().getAccountNo()));
		params.put(3, String.format("%.04f", tran.getTranAmount()));
		params.put(4, String.format("%.04f", tran.getStartBalance()));
		params.put(5, String.format("%.04f", tran.getEndBalance()));
		params.put(6, tran.getTransactionDescription());
		params.put(7, tran.getLocation());
		params.put(8, String.format("%d", tran.getTranType()));
		params.put(9, tran.getTranDate().toString());
		params.put(10, String.format("%d", tran.getCreatedBy().getUserID()));
		params.put(11, String.format("%d", tran.getToAccountNo().getAccountNo()));

		int result = dbProvider.addUpdateRow(SQL, params);

		if (result != 0)
			result = newID;

		return result;

	}

	@Override
	public Transaction getRecord(int tranID) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int updateRecord(Transaction object, int ID) {
		// TODO Auto-generated method stub

		return 0;
	}

	@Override
	public void deleteRecord(int ID) {
		// TODO Auto-generated method stub
	}

	@Override
	public int getNextID() {
		// TODO Auto-generated method stub
		String SQL = "SELECT max(id)+1 as nextID FROM 'Transaction'";
		int nextid = dbProvider.getNextID(SQL);
		return nextid;
	}

	public List<Transaction> getTransactionHistory(LocalDate fromDate, LocalDate toDate, int accountID) {
		String SQL = "SELECT * FROM 'transaction' WHERE CreatedDate between ? and ?  and (fromAccountID = ? or toAccountID = ?) order by CreatedDate desc";
		HashMap<Integer, String> params = new HashMap<Integer, String>();
		params.put(1, fromDate.toString());
		params.put(2, toDate.toString());
		params.put(3, String.format("%d", accountID));
		params.put(4, String.format("%d", accountID));

		List<HashMap<String, String>> result = dbProvider.getMultipleRows(SQL, params);

		List<Transaction> tranList = new ArrayList<Transaction>();
		for (HashMap<String, String> rs : result) {
			Transaction tran = null;
			// int tranid = Integer.parseInt(rs.get("ID"));
			int type = Integer.parseInt(rs.get("Type"));
			String desc = rs.get("Description");
			int createdBy = Integer.parseInt(rs.get("CreatedBy"));
			int toAccount = Integer.parseInt(rs.get("ToAccountID"));
			int fromAccount = Integer.parseInt(rs.get("FromAccountID"));
			double amount = Double.parseDouble(rs.get("Amount"));
			// double startBal = Double.parseDouble(rs.get("StartBalance"));
			// double endBal = Double.parseDouble(rs.get("EndBalance"));
			LocalDateTime createdDate = LocalDateTime.parse((CharSequence) rs.get("CreatedDate"));
			String location = rs.get("Location");
			if (type == 1) {
				tran = TransactionFactory.createDepositTransaction(amount, as.getRecord(toAccount), desc, location,
						us.getRecord(createdBy));
				tran.setTranDate(createdDate);
			} else if (type == 2) {
				tran = TransactionFactory.createWithdrawTransaction(amount, as.getRecord(toAccount), desc, location,
						us.getRecord(createdBy));
				tran.setTranDate(createdDate);
			} else if (type == 3) {
				tran = TransactionFactory.createTransferFund(amount, as.getRecord(fromAccount), as.getRecord(toAccount),
						desc, location, us.getRecord(createdBy));
				tran.setTranDate(createdDate);
			}
			tranList.add(tran);
		}

		return tranList;
	}

	public Result<Object> doTransfer(double tranAmount, String fromAccountNo, String toAccountNo, String toAccountName,
			String transactionDescription, String location, User createdBy) {
		Result<Object> res = new Result<>();

		boolean validate = validateAccount(toAccountNo, toAccountName);
		if (!checkAccountIsChecking(fromAccountNo)) {
			res.RetType = 30;
			res.RetDesc = "Sorry you can't transfer funds from your saving account in our system :)";
		} else if (!validate) {
			res.RetType = 10;
			res.RetDesc = "Receiver's account name and ID are not compatible";
		} else {
			Transaction tran = TransactionFactory.createTransferFund(tranAmount,
					as.getRecord(Integer.parseInt(fromAccountNo)), as.getRecord(Integer.parseInt(toAccountNo)),
					transactionDescription, location, createdBy);
			if (!TransactionFactory.doUpdate(tran)) {
				res.RetType = 20;
				res.RetDesc = "Insufficient balance";
			}
		}
		return res;

	}

	public Result<Object> doDeposit(double tranAmount, String toAccountNo, String toAccountName,
			String transactionDescription, String location, User createdBy) {

		Result<Object> res = new Result<>();
		boolean validate = validateAccount(toAccountNo, toAccountName);

		if (!validate) {
			res.RetType = 10;
			res.RetDesc = "Receiver's account name and ID are not compatible";
		} else {
			Transaction tran = TransactionFactory.createDepositTransaction(tranAmount,
					as.getRecord(Integer.parseInt(toAccountNo)), transactionDescription, location, createdBy);
			if (!TransactionFactory.doUpdate(tran)) {
				res.RetType = 99;
				res.RetDesc = "Unexpected error i think";
			}
		}
		return res;
	}

	public Result<Object> doWithdraw(double tranAmount, String fromAccountNo, String fromAccountName,
			String transactionDescription, String location, User createdBy) {
		Result<Object> res = new Result<>();

		boolean validate = validateAccount(fromAccountNo, fromAccountName);

		if (!checkAccountIsChecking(fromAccountNo)) {
			res.RetType = 30;
			res.RetDesc = "Sorry you can't withdraw from customer's saving account in BF system :)";
		} else if (!validate) {
			res.RetType = 11;
			res.RetDesc = "Customer's account name and ID are not compatible";
		} else {
			Transaction tran = TransactionFactory.createWithdrawTransaction(tranAmount,
					as.getRecord(Integer.parseInt(fromAccountNo)), transactionDescription, location, createdBy);
			if (!TransactionFactory.doUpdate(tran)) {
				res.RetType = 20;
				res.RetDesc = "Insufficient balance";
			}
		}
		return res;
	}

	private boolean validateAccount(String accountNo, String accountName) {
		String accountNameOfDB = as.getRecord(Integer.parseInt(accountNo)).getAccountName();
		accountName = accountName.toLowerCase();
		accountNameOfDB = accountNameOfDB.toLowerCase();
		return (accountName.contains(accountNameOfDB) || accountNameOfDB.contains(accountName));
	}

	private boolean checkAccountIsChecking(String accountNo) {
		int accountType = as.getRecord(Integer.parseInt(accountNo)).getAccountType();
		return (accountType == 1);
	}

	public static void main(String[] args) {

		// System.out.println(ts.getNextID());
		//
		// List<Transaction> trans = ts.getTransactionHistory(LocalDate.of(2017, 12,
		// 05), LocalDate.of(2017, 12, 06), 991);
		//
		// for(Transaction t : trans) {
		// System.out.println(t.getTransactionDescription());
		// }
		// Transaction tran = TransactionFactory.createDepositTransaction(4,
		// as.getRecord(991), "Income", "FF IO",
		// us.getRecord(3));
		// TransactionFactory.doUpdate(tran);

		// Transaction tran2 = TransactionFactory.createWithdrawTransaction(5,
		// as.getRecord(999), "Customer got money from his account", "FF IO",
		// us.getRecord(3));
		// TransactionFactory.doUpdate(tran);
	}
}
