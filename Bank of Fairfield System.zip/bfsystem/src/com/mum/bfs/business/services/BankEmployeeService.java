package com.mum.bfs.business.services;

import com.mum.bfs.business.interfaces.*;
import com.mum.bfs.business.models.*;

public class BankEmployeeService implements IService<Person> {
	
	public BankEmployeeService()
	{
		
	}
	
	@Override
	public int addRecord(Person object)
	{
		return 0;
	}
	
	@Override
	public Person getRecord(int ID)
	{
		return null;
	}
	
	@Override
	public int updateRecord(Person object, int ID)
	{
		return 0;
	}
	
	@Override
	public void deleteRecord(int ID)
	{
		
	}
	
	@Override
	public int getNextID()
	{
		return 0;
	}

}
