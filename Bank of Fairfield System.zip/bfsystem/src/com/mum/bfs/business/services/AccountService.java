package com.mum.bfs.business.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.*;
import java.util.HashMap;

import com.mum.bfs.business.interfaces.Account;
import com.mum.bfs.business.interfaces.IService;
import com.mum.bfs.business.models.AccountFactory;
import com.mum.bfs.business.models.Client;
import com.mum.bfs.dataaccess.DBConnection;
import com.mum.bfs.dataaccess.DBProvider;
import com.mum.bfs.tools.FilterListForAccount;
import com.mum.bfs.tools.Printer;
import com.mum.bfs.tools.Tools;

public class AccountService implements IService<Account> {

	private DBProvider dbProvider;

	public AccountService() {
		this.dbProvider = new DBProvider();
	}

	@Override
	public int addRecord(Account account) {
		// TODO Auto-generated method stub

		// int nextid = this.getNextID();
		String sql = "INSERT INTO account(ID,Name,CurrentBalance,BeginningBalance,OpenedDate,AccountType,AccountStatus,"
				+ "LastUpdated,UpdatedBy,ClientID,isBankAccount,InterestRate,SavingBookFee,MaturityOfSaving,MaintenanceFee) "
				+ "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

		HashMap<Integer, String> params = new HashMap<Integer, String>();
		int accountNo = account.getAccountNo();
		String accountName = account.getAccountName();
		double balance = account.getBalance();
		double minbalance = account.getMinimumBalance();
		LocalDate openedDate = account.getOpenedDate();
		int accountType = account.getAccountType();
		int accountStatus = 1;
		Client client = account.getClient();
		int isBankAcnt = account.isBankAccount() ? 1 : 0;
		double interestRate = account.getInterestRate();
		double savingBookFee = accountType == 2 ? 1 : 0;
		int maturityOfSaving = accountType == 2 ? account.getMaturityOfSaving() : 0;
		double maintenanceFee = accountType == 1 ? account.getMaintenanceFee() : 0.00;

		params.put(1, String.format("%d", accountNo));
		params.put(2, accountName);
		params.put(3, String.format("%.04f", balance));
		params.put(4, String.format("%.04f", minbalance));
		params.put(5, openedDate.toString());
		params.put(6, String.format("%d", accountType));
		params.put(7, String.format("%d", accountStatus));
		params.put(8, LocalDate.now().toString());
		params.put(9, String.format("%d", 2));
		params.put(10, String.format("%d", client.getClientID()));
		params.put(11, String.format("%d", isBankAcnt));
		params.put(12, String.format("%.02f", interestRate));
		params.put(13, String.format("%.02f", savingBookFee));
		params.put(14, String.format("%d", maturityOfSaving));
		params.put(15, String.format("%.02f", maintenanceFee));

		dbProvider = new DBProvider();
		int result = dbProvider.addUpdateRow(sql, params);

		return result;
	}

	@Override
	public Account getRecord(int ID) {
		// TODO Auto-generated method stub
		ClientService cs = new ClientService();
		Account acnt = null;
		Client client = null;
		HashMap<Integer, String> params = new HashMap<Integer, String>();
		String sql = "SELECT * FROM Account WHERE Account.ID = ?";
		params.put(1, String.format("%d", ID));
		dbProvider = new DBProvider();

		HashMap<String, String> rs = dbProvider.getRow(sql, params);
		if (rs != null && !rs.isEmpty()) {
			try {
				String name = rs.get("Name");
				Double currentBalance = Double.parseDouble(rs.get("CurrentBalance"));
				Double beginningBalance = Double.parseDouble(rs.get("BeginningBalance"));
				LocalDate openedDate = LocalDate.parse((CharSequence) rs.get("OpenedDate"));
				int accountType = Integer.parseInt(rs.get("AccountType"));
				int accountStatus = Integer.parseInt(rs.get("AccountStatus"));
				LocalDate lastUpdated = LocalDate.parse((CharSequence) rs.get("LastUpdated"));
				int updatedBy = Integer.parseInt(rs.get("UpdatedBy"));
				int clientID = Integer.parseInt(rs.get("ClientID"));
				boolean isBankAccount = Integer.parseInt(rs.get("IsBankAccount")) == 1 ? true : false;
				double interestRate = Double.parseDouble(rs.get("InterestRate"));
				int maturityOfSaving = Integer.parseInt(rs.get("MaturityOfSaving"));
				if (accountType == 1) {
					client = cs.getRecord(clientID);
					acnt = AccountFactory.createCheckingAccount(ID, name, currentBalance, isBankAccount, client);
					acnt.setInterestRate(interestRate);
					acnt.setMinimumBalance(beginningBalance);
					acnt.setOpenedDate(openedDate);
					acnt.setAccountStatus(accountStatus);
				} else if (accountType == 2) {
					acnt = AccountFactory.createSavingAccount(ID, name, currentBalance, isBankAccount, maturityOfSaving,
							cs.getRecord(clientID));
					acnt.setInterestRate(interestRate);
					acnt.setMinimumBalance(beginningBalance);
					acnt.setOpenedDate(openedDate);
					acnt.setAccountStatus(accountStatus);
				}

			} catch (Exception e) {
				Printer.printToConsole(e.getMessage());
				return null;
			}
		}

		return acnt;

	}

	@Override
	public int updateRecord(Account acnt, int ID) {
		// TODO Auto-generated method stub
		String sql = "UPDATE Account SET Name=?,CurrentBalance=?,BeginningBalance=?,OpenedDate=?,AccountType=?,"
				+ "AccountStatus=?,LastUpdated=?,UpdatedBy=?,ClientID=?,isBankAccount=?,InterestRate=?,"
				+ "SavingBookFee=?,MaturityOfSaving=?,MaintenanceFee=? WHERE ID=?";
		HashMap<Integer, String> params = new HashMap<Integer, String>();
		params.put(1, acnt.getAccountName());
		params.put(2, String.format("%.04f", acnt.getBalance()));
		params.put(3, String.format("%.04f", acnt.getMinimumBalance()));
		params.put(4, acnt.getOpenedDate().toString());
		params.put(5, String.format("%d", acnt.getAccountType()));
		params.put(6, String.format("%d", acnt.getAccountStatus()));
		params.put(7, LocalDate.now().toString());
		params.put(8, String.format("%d", 2)); // fix it..
		params.put(9, String.format("%d", acnt.getClient().getClientID()));
		params.put(10, String.format("%d", acnt.isBankAccount() ? 1 : 0));
		params.put(11, String.format("%.02f", acnt.getInterestRate()));
		params.put(12, String.format("%.02f", acnt.getSavingBookFee()));
		params.put(13, String.format("%d", acnt.getMaturityOfSaving()));
		params.put(14, String.format("%.02f", acnt.getMaintenanceFee()));
		params.put(15, String.format("%d", ID));
		dbProvider = new DBProvider();
		int result = dbProvider.addUpdateRow(sql, params);

		return result;
	}

	@Override
	public void deleteRecord(int ID) {
		// TODO Auto-generated method stub

	}

	@Override
	public int getNextID() {
		int result = 1;

		String sql = "select max(id)+1 as nextID from account";
		dbProvider = new DBProvider();
		result = dbProvider.getNextID(sql);
		return result;
	}

	public List<Account> getAccounts(FilterListForAccount filter) {

		List<Account> accounts = new ArrayList<Account>();
		ClientService cs = new ClientService();
		HashMap<Integer, String> params = new HashMap<Integer, String>();

		String accountID = filter.accountID;
		String clientID = filter.clientID;
		String personName = filter.personName;
		String phoneNumber = filter.phoneNumber;
		String email = filter.email;
		int filterCount = 0;
		int[] filters = new int[5];
		if (accountID != null) {
			filterCount++;
			filters[0] = 1;
		}
		if (clientID != null) {
			filterCount++;
			filters[1] = 1;
		}
		if (personName != null) {
			filterCount++;
			filters[2] = 1;
		}
		if (phoneNumber != null) {
			filterCount++;
			filters[3] = 1;
		}
		if (email != null) {
			filterCount++;
			filters[4] = 1;
		}

		String sql = "SELECT Account.* FROM Account\n" + "LEFT JOIN Client ON Account.ClientID = Client.ID\n"
				+ "LEFT JOIN Person ON Person.ID = Client.PersonID\n";
		if (filterCount > 0) {
			int c = 0;
			sql += "WHERE";
			if (filters[0] == 1) {
				sql += " Account.ID = ? OR";
				c++;
				params.put(c, accountID);
			}
			if (filters[1] == 1) {
				sql += " ClientID = ? OR";
				c++;
				params.put(c, clientID);
			}
			if (filters[2] == 1) {
				sql += " lower(FirstName) = ? OR lower(LastName) = ? OR";
				c++;
				params.put(c, personName.toLowerCase());
				c++;
				params.put(c, personName.toLowerCase());
			}
			if (filters[3] == 1) {
				sql += " ContactPhone = ? OR ContactPhone2 = ? OR";
				c++;
				params.put(c, phoneNumber);
			}
			if (filters[4] == 1) {
				sql += " lower(EmailAddress) = ? OR";
				c++;
				params.put(c, email.toLowerCase());
			}
			sql = sql.substring(0, sql.length() - 3);
		}

		dbProvider = new DBProvider();

		List<HashMap<String, String>> results = dbProvider.getMultipleRows(sql, params);

		for (HashMap<String, String> rs : results) {
			Account acnt = null;
			Client client = null;
			if (rs != null && !rs.isEmpty()) {
				try {
					String name = rs.get("Name");
					int accntID = Integer.parseInt(rs.get("ID"));
					Double currentBalance = Double.parseDouble(rs.get("CurrentBalance"));
					Double beginningBalance = Double.parseDouble(rs.get("BeginningBalance"));
					LocalDate openedDate = LocalDate.parse((CharSequence) rs.get("OpenedDate"));
					int accountType = Integer.parseInt(rs.get("AccountType"));
					int accountStatus = Integer.parseInt(rs.get("AccountStatus"));
					LocalDate lastUpdated = LocalDate.parse((CharSequence) rs.get("LastUpdated"));
					int updatedBy = Integer.parseInt(rs.get("UpdatedBy"));
					boolean isBankAccount = Integer.parseInt(rs.get("IsBankAccount")) == 1 ? true : false;
					double interestRate = Double.parseDouble(rs.get("InterestRate"));
					int maturityOfSaving = Integer.parseInt(rs.get("MaturityOfSaving"));
					String clientIDdb = rs.get("ClientID");
					if (accountType == 1) {
						client = cs.getRecord(Integer.parseInt(clientIDdb));
						acnt = AccountFactory.createCheckingAccount(accntID, name, currentBalance, isBankAccount,
								client);
						acnt.setInterestRate(interestRate);
						acnt.setMinimumBalance(beginningBalance);
						acnt.setOpenedDate(openedDate);
						acnt.setAccountStatus(accountStatus);
					} else if (accountType == 2) {
						acnt = AccountFactory.createSavingAccount(accntID, name, currentBalance, isBankAccount,
								maturityOfSaving, cs.getRecord(Integer.parseInt(clientIDdb)));
						acnt.setInterestRate(interestRate);
						acnt.setMinimumBalance(beginningBalance);
						acnt.setOpenedDate(openedDate);
						acnt.setAccountStatus(accountStatus);
					}

				} catch (Exception e) {
					Printer.printToConsole(e.getMessage());
					return null;
				}
			}

			if (acnt != null)
				accounts.add(acnt);

		}

		return accounts;

	}

	public static void main(String[] args) {
		AccountService a = new AccountService();
		FilterListForAccount filter = new FilterListForAccount();
		filter.personName = "jordan";
		// filter.accountID = "991";

		List<Account> accts = a.getAccounts(filter);

		for (Account acc : accts) {
			System.out.println(acc.getAccountNo() + "\t" + acc.getAccountName());
		}

		// System.out.println(a.getNextID());

		// Account act, act2;
		// Client client = PersonFactory.createClient(444, "Lastnnaa", "Midle hah",
		// "First", 65738);
		// act = AccountFactory.createCheckingAccount(123, "Hs checking", 1000, true,
		// client);
		// act2 = AccountFactory.createSavingAccount(999, "Hs saving 3", 9100, false, 6,
		// client);
		// // a.addRecord(act);
		// // a.addRecord(act2);
		//
		// act2.setAccountStatus(0);
		// act2.setInterestRate(0.12);
		// a.updateRecord(act2, 999);

		/*
		 * Account acnt = a.getRecord(1);
		 * 
		 * System.out.println(acnt.getAccountName());
		 * System.out.println(acnt.getClient().getAddress());
		 */

		// get accounts given a Client
		/* List<Account> accounts = a.getAccounts(65738); */

	}

}
